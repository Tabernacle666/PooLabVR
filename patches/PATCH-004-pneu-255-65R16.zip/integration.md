# PATCH-004 · Pneu 255/65 R16 sans jante

Asset de test MG2 à l'échelle 1:1, inspiré du Michelin Defender LTX M/S. La sculpture et la carcasse ont été reconstruites d'après les photos et dimensions publiques. Les photos du fabricant ne sont pas incluses.

| Dimension ou caractéristique | Valeur |
| --- | ---: |
| Diamètre extérieur nominal | 737,90 mm |
| Largeur de section maximale | 255,00 mm |
| Diamètre d'appui des deux talons | 406,40 mm |
| Profondeur nominale des canaux | 9,525 mm |
| Triangles du GLB source | 871 742 |
| Triangles de la carcasse | 795 806 |

Le GLB utilise les mètres, avec +Y vers le haut et l'axe de roue sur +Z. `pivot_roue` est au centre. Les nœuds `talon_exterieur` et `talon_interieur` repèrent les deux bords. La carcasse est une surface fermée, incluant les deux lèvres, les flancs et la doublure. La bande comprend cinq rangées, quatre canaux longitudinaux, des lamelles dans le mesh, des épaules festonnées et des témoins d'usure. Les inscriptions moulées sont des pièces rigides séparées du corps. Les sept images intégrées dérivent du matériau Rubber Tiles de Poly Haven, avec un recadrage hors joints et un grain adapté au caoutchouc.

Le GLB fournit le maillage détaillé à la sélection MG2 du moteur. Il est entièrement opaque. Lire les triangles réellement sélectionnés depuis le diagnostic en jeu. Vérifier la continuité des lamelles, des deux lèvres et de la silhouette en se rapprochant puis en reculant.

- Référence de silhouette et de sculpture : https://www.michelin.ca/fr/auto/pneus/michelin-defender-ltx-m-s/
- Tableau des dimensions : https://content.syndigo.com/asset/74044990-b64d-4bde-bc2e-96fbb5b73454/original.pdf
- Texture CC0 recadrée et adaptée : https://polyhaven.com/a/rubber_tiles
- Licence des cartes source : https://polyhaven.com/license
