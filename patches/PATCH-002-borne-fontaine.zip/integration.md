# PATCH-002 · Borne-fontaine rouge

GLB autonome. Mètres, +Y haut, +Z avant. Origine au sol. Hauteur hors sol de 0,93 m.

| Nœud | Usage futur dans OASIS |
| --- | --- |
| `socket_water_in` | Entrée d'eau froide, axe local +Z vers le bas, position à −92 mm du sol. |
| `socket_water_out_principal` | Origine et axe de sortie du jet principal. Les nœuds `socket_water_out_gauche` et `socket_water_out_droit` servent aux sorties latérales. |
| `socket_valve_actuation` | Commander la sortie d'eau et faire tourner `tige_de_vanne` autour de son +Y local. |
| `bouchon_principal`, `bouchon_gauche`, `bouchon_droit` | Pivot dans l'axe du raccord, +Z local pour dévissage. Les chaînes latérales ont leurs propres nœuds. |

Corps et raccords groupés. Sections arrondies, filets hélicoïdaux, lèvres de joints, attaches et vis en géométrie. Les matériaux sont opaques. Le GLB fournit le mesh source à la simplification MG2. Les nœuds de raccord et les pièces mobiles gardent leurs identités pour l'intégration.

Mesh source de 40372 triangles, 7 matériaux et 6 images intégrées. Validation glTF sans erreur ni avertissement. La sélection MG2 et les actions restent à qualifier dans OASIS.

Cartes PBR embarquées, d'après Blue Metal Plate et Metal Plate 02 de Poly Haven (CC0).
Le recadrage sans joints, la mise en répétition, la recoloration et le grain ajouté sont propres à ces assets.
- https://polyhaven.com/a/blue_metal_plate
- https://polyhaven.com/a/metal_plate_02
- https://polyhaven.com/license
