# PATCH-003 · Lampadaire ambre

GLB autonome. Mètres, +Y haut, +Z avant. Origine au sol. Hauteur hors sol de 3,88 m environ.

| Nœud | Usage futur dans OASIS |
| --- | --- |
| `socket_power_in` | Arrivée du fil à 65 mm sous le niveau du sol. Axe local +Z vers le bas. |
| `socket_light_amber` | Origine d'une lumière dirigée vers le sol. Température indicative de 2 200 K. |
| `ampoule_ambre_mobile` | Activer l'émission du matériau `ampoule_ambre` en même temps que la source. |
| `trappe_entretien` | Ouverture autour du +Y local au niveau des charnières. |

Le GLB est livré éteint. Les aperçus montrent l'état allumé. Le verre BLEND est isolé dans `verre_prismatique` pour le chemin translucide existant. Le mât, le réflecteur et la tête forment les surfaces opaques à traiter par MG2.

Mesh source de 23952 triangles, 9 matériaux et 6 images intégrées. Validation glTF sans erreur ni avertissement. La sélection MG2 et les actions restent à qualifier dans OASIS.

Cartes PBR embarquées, d'après Blue Metal Plate et Metal Plate 02 de Poly Haven (CC0).
Le recadrage sans joints, la mise en répétition, la recoloration et le grain ajouté sont propres à ces assets.
- https://polyhaven.com/a/blue_metal_plate
- https://polyhaven.com/a/metal_plate_02
- https://polyhaven.com/license
