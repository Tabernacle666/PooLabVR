# PATCH-007 · Regards de voirie en fonte

Deux pièces de dessus et un cadre commun, en GLB. Modèles et cartes PBR originaux. Les trois origines coïncident au centre du regard, à la hauteur de la chaussée. En glTF, +Y est le haut.

| Fichier | Rôle |
| --- | --- |
| cadre_commun_810.glb | Cadre fixe de Ø810 mm hors tout, avec épaulement de portée à −55 mm et passage libre de Ø626 mm sous l'épaulement. |
| tampon_plein.glb | Tampon amovible à motif moulé en relief et deux lumières traversantes de 23 × 53 mm avant chanfrein. La face principale est à −4 mm, le relief s'approche du niveau de la route. |
| tampon_grille.glb | Grille ronde avec onze ajours traversants et leur chanfrein d'entrée. La surface des barreaux arrive au niveau de la route. |

Les deux variantes ont un dessus de Ø692 mm et un talon inférieur de Ø614 mm. Le cadre les centre et reprend leur charge par l'épaulement. Pour la pose, réserver la place du cadre dans la chaussée. Le couvercle et son motif se déplacent ensemble. Le cadre reste fixe. Le coffre et le puits sont fournis par la scène.

Le manifeste expose les choix plein et grille. Fixer le choix lorsqu'un emplacement remplit une fonction précise. Pour les placements libres, tirer parmi les variantes admissibles avec la graine du monde et l'identifiant stable du placement. Conserver le résultat à la reprise. L'angle peut être fixé pour orienter les ajours par rapport à la chaussée.

Les ajours sont des ouvertures géométriques. Vérifier le passage de la lumière et l'occultation en vue rasante, puis tester la collision du cadre et du dessus choisi. Une caméra placée dans le puits d'essai doit voir le ciel à travers la grille. Le puits, le déplacement et la collision restent à intégrer dans OASIS.
