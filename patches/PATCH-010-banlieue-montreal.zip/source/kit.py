from pathlib import Path
from math import sin,cos,pi,tau,hypot,atan2,exp
import sys
import random
import bpy
import bmesh
from mathutils import Vector

DIR=Path(__file__).resolve().parent
sys.path.insert(0,str(DIR))
import helpers as H
H.MAPS=DIR/'maps'
X=Vector((1,0,0))
Y=Vector((0,1,0))
Z=Vector((0,0,1))
F=-Y
PERIOD=.52
MATERIALS={}
STATE="neuf"

def mat(name,color,rough,metal=0,texture=None,alpha=1):
    material=H.material(name,color,rough,metal,maps=texture,alpha=alpha)
    MATERIALS[name]=material
    return material

def base(name):
    return MATERIALS[name]

def texture(base_name, rough='metal_rough.jpg', normal='metal_normal.jpg'):
    return (base_name+'.jpg',rough,normal)

def woodmap(base_name):
    return texture(base_name,'wood_rough.jpg','wood_normal.jpg')

def reset(state):
    global STATE
    STATE=state
    used=state!="neuf"
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATERIALS.clear()
    mat("aluminium",(.32,.37,.40),.48,.61,texture('alu_use' if used else 'alu'))
    for node in base("aluminium").node_tree.nodes:
        if node.type=="NORMAL_MAP":
            node.inputs["Strength"].default_value=.26
    mat("acier_peint_gris",(.56,.58,.57),.54,.16,texture('gris_poste_use' if used else 'gris_poste'))
    mat("acier_forge_noir",(.079,.086,.084),.56,.29,texture('fer_use' if used else 'fer'))
    mat("acier_galvanise",(.38,.41,.40),.55,.69,texture('alu_use' if used else 'alu'))
    mat("acier_nu",(.33,.33,.31),.40,.77,texture('alu'))
    mat("bois_teinte_miel",(.49,.275,.108),.48,texture=woodmap('bois_grise' if used else 'bois_miel'))
    mat("bois_peint_vert",(.08,.23,.15),.54,texture=woodmap('vert_use' if used else 'vert'))
    mat("bois_expose",(.65,.47,.30),.75,texture=woodmap('bois_miel'))
    mat("joint_epdm",(.016,.020,.022),.86)
    mat("noir_ecran",(.0032,.004,.005),.59)
    mat("bleu_signal",(.016,.202,.552),.50)
    mat("jaune_signal",(.98,.65,.034),.48)
    mat("blanc_signal",(.89,.87,.80),.61)
    mat("rouge_postal",(.44,.024,.033),.55)
    mat("verre_trempe",(.73,.90,.86),.13,alpha=.09)
    glass=base("verre_trempe")
    if used:
        nodes=glass.node_tree.nodes;links=glass.node_tree.links
        node=nodes.new("ShaderNodeTexImage")
        node.image=bpy.data.images.load(str(H.MAPS/'verre_use.png'),check_existing=True)
        links.new(node.outputs["Color"],nodes.get("Principled BSDF").inputs["Base Color"])
        links.new(node.outputs["Alpha"],nodes.get("Principled BSDF").inputs["Alpha"])
    glass.use_backface_culling=True

def root(name,**data):
    return H.empty(name,asset_id=name,state=STATE,unit="m",**data)

def attach(obj,owner):
    obj.parent=owner
    return obj

def props(obj, **data):
    for k,v in data.items():obj[k]=v
    return obj

def product_mat(name):
    if name.startswith("bois"):return "wood"
    if name.startswith("verre"):return "glass"
    if name.startswith("noir_ecran"):return "display"
    if name.startswith("joint"):return "rubber"
    if name.startswith("sol"):return "concrete"
    return "metal"

def box(name,center,dims,material,parent,edge=.0014,grain=None,phase=(0,0),**extras):
    bpy.ops.mesh.primitive_cube_add(size=1,location=center)
    o=bpy.context.object
    o.name=name
    o.data.name=name
    o.dimensions=dims
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(base(material))
    if edge:
        b=o.modifiers.new("rayon","BEVEL");b.width=edge;b.segments=2
        bpy.ops.object.modifier_apply(modifier=b.name)
    tr=o.modifiers.new("tri","TRIANGULATE")
    bpy.ops.object.modifier_apply(modifier=tr.name)
    uv=o.data.uv_layers.active
    for poly in o.data.polygons:
        axis=max(range(3),key=lambda j:abs(poly.normal[j]))
        uv_axes=[j for j in range(3) if j!=axis]
        if grain in uv_axes:
            uv_axes.remove(grain);uv_axes.append(grain)
        for li in poly.loop_indices:
            p=o.data.vertices[o.data.loops[li].vertex_index].co
            uv.data[li].uv=tuple(p[j]/PERIOD+phase[k] for k,j in enumerate(uv_axes))
    return props(attach(o,parent),component_id=name,material_profile=product_mat(material),**extras)

def text_object(name,txt,loc,size,mat_name,parent,mode='front'):
    bpy.ops.object.text_add(location=loc)
    o=bpy.context.object;o.name=name
    o.rotation_euler=(pi/2,0,pi/2 if mode=="end" else 0)
    o.data.body=txt;o.data.size=size;o.data.align_x='CENTER';o.data.align_y='CENTER'
    o.data.materials.append(base(mat_name))
    bpy.ops.object.convert(target='MESH')
    o=bpy.context.object
    return attach(o,parent)

def polygon(name,points,n,u,v,mat_name,parent,**data):
    p=H.Part(name,**data)
    p.face([p.point(q) for q in points],[(0,0),(1,0),(1,1),(0,1)],base(mat_name),False)
    return attach(p.finish(),parent)

def fastener_set(name, coords, axis, material, owner, r=.0065,h=.0043):
    part=H.Part(name,material_profile="metal",role="hardware")
    for c in coords:H.bolt(part,c,axis,r,h,base(material))
    return attach(part.finish(),owner)

def bar_path(part, path, flat, thick, ref, mat_name, scale=None):
    # Octagonal bar with true chamfers on both longitudinal edges.
    profile=((-.5,-.36),(-.36,-.5),(.36,-.5),(.5,-.36),(.5,.36),(.36,.5),(-.36,.5),(-.5,.36))
    path=[Vector(p) for p in path]
    rings=[];along=[0.]
    for i,pos in enumerate(path):
        if i:along.append(along[-1]+(pos-path[i-1]).length/PERIOD)
        tan=(path[min(i+1,len(path)-1)]-path[max(0,i-1)]).normalized()
        a=(ref-tan*ref.dot(tan)).normalized()
        b=tan.cross(a)
        s=scale[i] if scale else 1
        rings.append([part.point(pos+u*flat*s*a+v*thick*s*b) for u,v in profile])
    n=len(profile)
    for i,(a,b) in enumerate(zip(rings,rings[1:])):
        for j in range(n):
            k=(j+1)%n
            part.face((a[j],a[k],b[k],b[j]),((j/n,along[i]),((j+1)/n,along[i]),((j+1)/n,along[i+1]),(j/n,along[i+1])),base(mat_name),False)
    uv=[(u+.5,v+.5) for u,v in profile]
    part.face(rings[0][::-1],uv[::-1],base(mat_name),False)
    part.face(rings[-1],uv,base(mat_name),False)

def radial_box(name,angle,radius,z,dims,material,parent,edge=.0016,**extra):
    o=box(name,(radius*cos(angle),radius*sin(angle),z),dims,material,parent,edge=edge,grain=2,phase=(angle/tau,.21*angle),**extra)
    o.rotation_euler.z=angle
    return o

def socket(p,name,loc,**extras):
    return attach(H.empty(name,loc,role="socket",**extras),p)

def glass_panel(name,p,c,dims):
    return box(name,c,dims,"verre_trempe",p,edge=0,role="breakable_glass",fracture_group=name)

def screen(parent,preview=False):
    o=attach(H.empty("module_publicitaire",component_id="module_publicitaire",role="video_display"),parent)
    x=1.844; y=.0; z=1.249
    shell=box("coffret_ecran",(x,y,z),(.108,1.003,1.699),"aluminium",o,edge=.011)
    front=x+.055
    frame=box("cerclage_ecran",(front,y,z),(.021,.922,1.610),"acier_forge_noir",o,edge=.008)
    front+=.0114
    picture="noir_ecran"
    if preview:
        m=mat("publicite_apercu",(.55,.55,.55),.61)
        tree=m.node_tree
        image=tree.nodes.new('ShaderNodeTexImage')
        image.image=bpy.data.images.load(str(H.MAPS/'pub_oasis.jpg'),check_existing=True)
        bsdf=tree.nodes.get('Principled BSDF')
        tree.links.new(image.outputs['Color'],bsdf.inputs['Base Color'])
        tree.links.new(image.outputs['Color'],bsdf.inputs['Emission Color'])
        bsdf.inputs['Emission Strength'].default_value=.65
        picture="publicite_apercu"
    w=.810; h=1.440
    polygon("surface_video_9x16",[(front,y+dw*w/2,z+dh*h/2) for dw,dh in [(-1,-1),(1,-1),(1,1),(-1,1)]],
            X,Y,Z,picture,o,role="video_surface",component_id="surface_video_9x16",material_profile="display",
            aspect_ratio="9:16",width_m=w,height_m=h,default_state="black",uv_role="video")
    pane=box("vitrage_protection_ecran",(front+.008,y,z),(.005,.888,1.570),
             "verre_trempe",o,edge=0,role="breakable_glass",fracture_group="ecran")
    box("socle_ecran",(x,0,.291),(.091,.760,.270),"aluminium",o,edge=.009)
    box("trappe_service",(x-.054,0,.457),(.009,.720,.137),"acier_peint_gris",o,edge=.003)
    fastener_set("fixations_trappe",[(x-.061,yy,zz) for yy in (-.326,.326) for zz in (.416,.498)],-X,"acier_nu",o)
    return o

def signage(parent):
    root=attach(H.empty("identification_STM",role="signage"),parent)
    box("bandeau_bleu",(-1.215,-.805,2.316),(1.126,.012,.112),"bleu_signal",root,edge=.002)
    box("bandeau_jaune",(-.546,-.805,2.316),(.215,.012,.112),"jaune_signal",root,edge=.002)
    text_object("marquage_stm","STM  /  BUS",(-1.215,-.812,2.315),.066,"blanc_signal",root)
    box("panneau_ligne",(-1.595,.736,1.555),(.326,.048,.500),"aluminium",root,edge=.005)
    box("panneau_ligne_face",(-1.595,.710,1.561),(.307,.005,.478),"blanc_signal",root,edge=.002)
    box("liseret_bleu",(-1.595,.706,1.753),(.307,.003,.097),"bleu_signal",root,edge=.001)
    text_object("route","BUS",(-1.595,.704,1.753),.049,"blanc_signal",root)
    for i,n in enumerate(("18","185","Nuit")):
        text_object("ligne_exemple",n,(-1.595,.705,1.627-i*.092),.066 if i<2 else .040,"bleu_signal",root)
    return root

def abribus(show=False):
    p=root("abribus_montreal",footprint_m=[3.820,1.600],height_m=2.410,
           primary_action="play_pause_mp4",power_socket="socket_power_in",video_surface="surface_video_9x16")
    front=-.690; back=.744
    for xpos in (-1.787,-.600,.600,1.787):
        for y in ((back,front) if abs(xpos)>1 else (back,)):
            suffix=('_G' if xpos<0 else '_D')+('_avant' if y<0 else '_arriere')+f'_{abs(round(100*xpos))}'
            box("montant"+suffix,(xpos,y,1.136),(.070,.068,2.272),"aluminium",p,edge=.006)
            box("platine"+suffix,(xpos,y,.012),(.141,.135,.024),"aluminium",p,edge=.004)
            fastener_set("ancrage"+suffix,[(xpos+x,y+t,.023) for x in (-.046,.046) for t in (-.044,.044)],
                         Z,"acier_nu",p,.008)
    roof=box("toiture",(0,0,2.337),(3.820,1.600,.146),"aluminium",p,edge=.016)
    box("intrados",(0,0,2.258),(3.680,1.465,.025),"acier_peint_gris",p,edge=.005)
    for side in (-1,1):
        sleeve=box("profil_gouttiere_"+str(side),(0,side*.778,2.342),(3.770,.033,.066),"aluminium",p,edge=.006)
        box("gorge_gouttiere_"+str(side),(0,side*.797,2.316),(3.745,.004,.010),"joint_epdm",p,edge=.001)
    for side,x1,x2 in [('G',-1.752,-.635),('C',-.565,.565),('D',.635,1.752)]:
        mid=(x1+x2)/2
        w=x2-x1
        if not(STATE=="endommage" and side=="C"):
            g=glass_panel("vitre_fond_"+side,p,(mid,back,1.218),(w,.010,1.823))
            for k,(z,m) in enumerate(((1.153,"bleu_signal"),(1.116,"jaune_signal"))):
                line=box("signal_vitre_"+side+str(k),(0,-.00545,0),(w-.003,.0007,.021),m,None,edge=0,role="glass_marking")
                line.parent=g;line.location.z=z-1.218
        else:
            props(socket(p,"vitre_fond_C_absente",(mid,back,1.218)),component_id="vitre_fond_C",state="broken")
        for name,zz in (("bas",.300),("haut",2.139)):
            box("rail_"+side+"_"+name,(mid,back,zz),(w,.047,.034),"aluminium",p,edge=.003)
        for a in (x1,x2):
            box("joint_fond_"+side,(a,back-.009,1.217),(.012,.012,1.831),"joint_epdm",p,edge=.001)
    glass_panel("vitre_pignon_gauche",p,(-1.787,(back+front)*.5,1.217),(.010,back-front-.070,1.813))
    for zz in (.286,2.143):
        box("rail_pignon_gauche",(-1.787,(back+front)*.5,zz),(.047,back-front-.060,.037),"aluminium",p,edge=.003)
    for z,m in ((1.153,"bleu_signal"),(1.116,"jaune_signal")):
        box("signal_pignon",(-1.7805,(back+front)*.5,z),(.0009,back-front-.071,.021),m,p,edge=0)
    for x in (-1.15,-.35):
        box("appui_assise",(x,.534,.372),(.045,.260,.141),"aluminium",p,edge=.009)
    for i in range(4):
        box(f"latte_attente_{i:02d}",(-.741,.342+i*.092,.451),(1.44,.087,.035),"bois_teinte_miel",p,
            edge=.004,grain=0,phase=(.11*i,.09*i))
    box("luminaire_sous_toit",(0,.37,2.237),(1.72,.066,.021),"blanc_signal",p,edge=.004)
    signage(p)
    screen(p,show)
    socket(p,"socket_power_in",(1.785,.699,-.036),port="electric_input",engine_signal="powered")
    socket(p,"origine_pose",(0,0,0))
    return p

def dent_sheet(name,c,w,h,parent):
    p=H.Part(name,c,role="door_skin",material_profile="metal",damage="dent")
    ns=18
    rings=[]
    for depth in (-.005,.005):
        ring=[]
        for j in range(ns+1):
            for i in range(ns+1):
                a=w*(i/ns-.5);z=h*(j/ns-.5)
                sag=.020*exp(-(a/w/.26)**2-((z/h+.04)/.25)**2)
                p0=Vector(c)+Vector((a,depth+sag,z))
                ring.append(p.point(p0))
        rings.append(ring)
    def face(recs):
        p.face(recs,[(p.v[k][0]/PERIOD+p.v[k][1]/PERIOD*.35,p.v[k][2]/PERIOD+p.v[k][1]/PERIOD*.72) for k in recs],base("acier_peint_gris"),True)
    n=ns+1
    for j in range(ns):
        for i in range(ns):
            a=j*n+i
            points=(a,a+1,a+n+1,a+n)
            for q in (0,1):
                ids=[rings[q][k] for k in points]
                face(ids if q==0 else ids[::-1])
    rim=[i for i in range(n)]+[j*n+ns for j in range(1,n)]+[ns*n+i for i in range(ns-1,-1,-1)]+[j*n for j in range(ns-1,0,-1)]
    for a,b in zip(rim,rim[1:]+rim[:1]):face((rings[0][b],rings[0][a],rings[1][a],rings[1][b]))
    return attach(p.finish(),parent)

def mailbox(open_door=False):
    o=root("boite_postale_communautaire",dimensions_m=[.780,.518,1.663],primary_action="open_assigned_compartment")
    box("semelle", (0,0,.012),(.408,.344,.024),"acier_galvanise",o,edge=.003)
    box("pied", (0,0,.163),(.294,.251,.323),"acier_peint_gris",o,edge=.009)
    box("bride_pied", (0,0,.309),(.395,.292,.032),"acier_galvanise",o,edge=.006)
    fastener_set("ancrages",[(xx,yy,.024) for xx in (-.163,.163) for yy in (-.129,.129)],Z,"acier_nu",o,.008)
    for x,side in ((-.377,"G"),(.377,"D")):
        box("flanc_"+side,(x,.005,.976),(.026,.484,1.286),"acier_peint_gris",o,edge=.005)
    box("dos_fond",(0,.237,.976),(.732,.026,1.284),"acier_peint_gris",o,edge=.004)
    box("fond", (0,.003,.339),(.736,.486,.026),"acier_galvanise",o,edge=.004)
    box("couvercle", (0,0,1.640),(.780,.518,.046),"acier_peint_gris",o,edge=.009)
    box("separation_casiers",(0,.003,.954),(.022,.466,1.192),"acier_galvanise",o,edge=.003)
    box("bandeau_postal", (0,-.244,1.577),(.731,.021,.092),"rouge_postal",o,edge=.003)
    text_object("marque_bilingue","POSTES CANADA  /  CANADA POST",(0,-.2554,1.577),.035,"blanc_signal",o)
    for col,int_x in [('G',-.186),('D',.186)]:
        seq=[(.275,"colis")]+[(.108,"lettres")]*8 if col=="G" else [(.095,"lettres")]*5+[(.237,"colis")]+[(.101,"lettres")]*4
        z=.352
        for i,(hh,typ) in enumerate(seq):
            name=f'casier_{col}_{i+1:02d}'
            w=.340
            if i>0:box('tablette_'+name,(int_x,.010,z),(w,.447,.013),"acier_galvanise",o,edge=.001)
            pivot_x=int_x-w/2
            leaf=attach(H.empty(name,(pivot_x,-.247,z+hh/2),role="mailbox_door",
                                component_id=name,compartment=typ,rotation_axis="+Y",
                                open_deg=94,primary_requires="assigned_compartment"),o)
            if open_door and col=="D" and typ=="colis":leaf.rotation_euler.z=-pi*.42
            if STATE=="endommage" and col=="G" and i==0:
                skin=dent_sheet("peau_"+name,(w/2,0,0),w-.006,hh-.006,leaf)
            else:
                skin=box("peau_"+name,(w/2,0,0),(w-.006,.013,hh-.006),"acier_peint_gris",leaf,edge=.0024)
            for zz in (-(hh*.32),hh*.32):
                part=H.Part("axe_"+name,material_profile="metal",role="hardware")
                H.collar(part,(.006,-.003,zz-.017),Z,.034,.0052,base("acier_nu"),14)
                attach(part.finish(),leaf)
            lock=H.Part("pastille_"+name,role="decorative_lock",material_profile="metal")
            H.collar(lock,(w-.034,-.008,0),F,.004,.0095,base("acier_nu"),18)
            attach(lock.finish(),leaf)
            text_object("numero_"+name,("P" if typ=="colis" else col)+f"{i+1:02d}",(w*.46,-.0072,0),.0185,"acier_forge_noir",leaf)
            z+=hh
        box("traverse_haute_"+col,(int_x,-.240,(z+1.531)*.5),(.350,.027,1.531-z),"acier_peint_gris",o,edge=.002)
    socket(o,"ancrage",(0,0,0))
    return o

def split_plank(name,start,end,y,z,width,depth,material,parent,seed,damage_side):
    p=H.Part(name,component_id=name,material_profile="wood",damage="splintered")
    rng=random.Random(seed)
    k=15
    lo=[];hi=[]
    for i in range(k):
        normal=i/(k-1)
        across=y+width*(normal-.5)
        line=end + damage_side*(.007*cos(normal*11)+rng.uniform(-.020,.027))
        lo.append(p.point((line,across,z-depth/2+damage_side*rng.uniform(-.004,.004))))
        hi.append(p.point((line+.006*sin(normal*8),across,z+depth/2)))
    x0=start
    low0=[p.point((x0,y+width*(i/(k-1)-.5),z-depth/2)) for i in range(k)]
    high0=[p.point((x0,y+width*(i/(k-1)-.5),z+depth/2)) for i in range(k)]
    def face(f,m):
        coords=[(p.v[j][1]/PERIOD+.24*p.v[j][2],(p.v[j][0]+p.v[j][2])/PERIOD) for j in f]
        p.face(f if damage_side>0 else f[::-1],coords if damage_side>0 else coords[::-1],base(m),False)
    for i in range(k-1):
        face([high0[i],hi[i],hi[i+1],high0[i+1]],material)
        face([low0[i+1],lo[i+1],lo[i],low0[i]],material)
        face([lo[i],lo[i+1],hi[i+1],hi[i]],"bois_expose")
        face([low0[i],high0[i],high0[i+1],low0[i+1]],material)
    face([low0[0],lo[0],hi[0],high0[0]],material)
    face([lo[-1],low0[-1],high0[-1],hi[-1]],material)
    return attach(p.finish(),parent)

def bench():
    o=root("banc_parc_fer_forge",dimensions_m=[1.930,.665,.820],seat_height_m=.444,primary_action="sit")
    m="acier_forge_noir"
    for x,tag in ((-.801,"G"),(.801,"D")):
        p=H.Part("pietement_forge_"+tag,component_id="pietement_"+tag,material_profile="metal")
        def bar(yz,w,t,taper=False):
            bar_path(p,[(x,y,z) for y,z in yz],w,t,X,m,
                     [1-.30*i/max(1,len(yz)-1) for i in range(len(yz))] if taper else None)
        bar([(-.239,.019),(-.206,.105),(-.143,.213),(-.104,.306),(-.124,.363),(-.188,.410)],.043,.040)
        bar([(.280,.017),(.208,.114),(.134,.210),(.120,.305),(.165,.390),(.228,.434),(.274,.526),(.294,.639),(.299,.734),(.300,.820)],.044,.040)
        bar([(-.25,.417),(-.172,.416),(-.106,.410),(-.045,.405),(.025,.406),(.091,.412),(.172,.426),(.225,.440)],.045,.041)
        bar([(-.194,.401),(-.236,.465),(-.270,.529),(-.247,.565),(-.183,.574),(-.096,.566),(0,.561),(.090,.565),(.179,.583),(.255,.603),(.279,.592)],.034,.033)
        for c,mirror in (((-.001,.264),1),((.020,.155),-1)):
            points=[]
            for i in range(42):
                t=i/41;ang=(.01+1.14*t)*tau*mirror;rad=.132*(1-t)**1.12+.010
                points.append((c[0]+rad*cos(ang),c[1]+rad*sin(ang)*.86))
            bar(points,.025,.023,True)
        attach(p.finish(),o)
        for y in (-.277,.273):
            box('sabot_'+tag,(x,y,.012),(.079,.115,.024),m,o,edge=.004)
            fastener_set("ancrage_"+tag,[(x,y-.038,.024),(x,y+.038,.024)],Z,"acier_nu",o,.0063)
    wood="bois_teinte_miel"
    for i in range(5):
        y=-.226+.092*i
        z=.424+.013*cos((i+.85)*.48)
        tag=f"latte_assise_{i:02d}"
        if STATE=="endommage" and i==1:
            split_plank(tag+"_G",-.965,-.196,y,z,.084,.032,wood,o,3,1)
            split_plank(tag+"_D",.965,.011,y,z,.084,.032,wood,o,25,-1)
            props(socket(o,tag+"_etat",(-.095,y,z)),component_id=tag,state="split")
        else:
            box(tag,(0,y,z),(1.930,.084,.032),wood,o,edge=.0042,grain=0,phase=(.16*i,.215*i))
        fastener_set("vis_"+tag,[(s*.800,y,z+.0157) for s in (-1,1)],Z,"acier_nu",o,.0055,.0025)
    for i in range(4):
        tag=f"latte_dossier_{i:02d}"
        y=.217+.024*i; z=.520+.085*i
        blade=box(tag,(0,y,z),(1.930,.029,.073),wood,o,edge=.004,grain=0,phase=(.31*i,.19*i))
        blade.rotation_euler.x=-.23
        fastener_set("vis_"+tag,[(s*.800,y-.015,z-.004) for s in (-1,1)],F,"acier_nu",o,.0055,.0025)
    for x in (-.48,.48):
        seat=socket(o,"place_G" if x<0 else "place_D",(x,-.006,.444),action="sit",facing="+Z")
    return o

def turned(name,rows,material,parent,sides=96,**data):
    p=H.Part(name,component_id=name,material_profile=product_mat(material),**data)
    H.profile(p,(0,0,0),Z,rows,base(material),sides,period=.48)
    return attach(p.finish(),parent)

def ring_band(name, ro, z0,z1,parent,th=.005):
    ri=ro-th;b=.0015
    return turned(name,[(z0,ri),(z0,ro-b),(z0+b,ro),(z1-b,ro),(z1,ro-b),(z1,ri),
                        (z0,ri)],"acier_forge_noir",parent)

def rubbish_bin(show_liner=False):
    o=root("corbeille_verte_cerceaux",diameter_m=.464,height_m=.737,primary_action="deposit",
           secondary_action="remove_liner")
    ring_band("cerceau_superieur",.232,.615,.698,o,.006)
    ring_band("cerceau_inferieur",.232,.066,.145,o,.006)
    for i in range(24):
        angle=i*tau/24
        name=f"latte_verte_{i+1:02d}"
        if STATE=="endommage" and i in (18,19):
            props(socket(o,name+"_absente",(.206*cos(angle),.206*sin(angle),.368)),component_id=name,state="missing")
            continue
        radial_box(name,angle,.2045,.380,(.044,.045,.644),"bois_peint_vert",o,edge=.0033)
    for i in range(8):
        a=i*tau/8
        for z in (.107,.656):
            p=H.Part("rivet_cerceau",role="hardware",material_profile="metal")
            axis=Vector((cos(a),sin(a),0))
            H.collar(p,axis*.2315+Z*z,axis,.004,.006,base("acier_nu"),12)
            attach(p.finish(),o)
    lid=turned("collerette",[(.687,.154),(.690,.219),(.700,.231),(.722,.232),(.737,.221),
                           (.737,.167),(.733,.157),(.723,.154),(.687,.154)],"acier_forge_noir",o,role="opening")
    liner=attach(H.empty("bac_interieur",component_id="bac_interieur",role="removable_liner",lift_axis="+Y",removable=True),o)
    turned("seau_galvanise",[(.071,0),(.071,.140),(.079,.149),(.631,.203),(.644,.205),(.644,.191),
                           (.628,.192),(.093,.139),(.093,0)],"acier_galvanise",liner,role="liner")
    turned("support_fond",[(.038,0),(.038,.153),(.054,.158),(.061,.155),(.061,0)],"acier_forge_noir",o)
    for i in range(3):
        radial_box("patin",i*tau/3,.142,.019,(.081,.059,.038),"acier_forge_noir",o)
    socket(o,"centre_depot",(0,0,.744),opening_diameter_m=.308)
    return o

def export(o):
    output=DIR/'kit';output.mkdir(exist_ok=True)
    bpy.ops.export_scene.gltf(
        filepath=str(output/(o.name+'_'+STATE+'.gltf')),export_format='GLTF_SEPARATE',
        export_texture_dir='textures',export_extras=True,export_tangents=True,export_yup=True,
        export_draco_mesh_compression_enable=False)

def environment():
    mat("sol_beton",(.48,.46,.37),.79,texture=texture('beton_base','beton_rough.jpg','beton_normal.jpg'))
    mat("sol_bitume",(.17,.16,.15),.91,texture=texture('route_base','beton_rough.jpg','route_normal.jpg'))
    mat("herbe",(.151,.217,.112),.95)
    mat("terre_jardin",(.15,.093,.054),.95)
    mat("feuillage_0",(.091,.155,.057),.90)
    mat("feuillage_1",(.121,.239,.100),.90)
    mat("feuillage_2",(.188,.278,.106),.90)
    mat("tronc",(.13,.081,.048),.92)
    mat("brique",(.42,.255,.173),.86)
    mat("brique_alt",(.48,.291,.199),.84)
    mat("mortier",(.55,.50,.38),.90)
    o=H.empty("decor_rendu")
    box("chaussee",(0,-8.0,-.198),(80,19,.16),"sol_bitume",o,edge=0)
    for ix in range(-9,10):
        for iy in range(3):
            box("trottoir",(ix*1.23,-1.12+iy*1.11,-.068),(1.224,1.104,.136),"sol_beton",o,edge=.0026,
                phase=(ix*.34,iy*.31))
        box("bordure",(ix*1.23,-1.748,-.038),(1.224,.146,.196),"sol_beton",o,edge=.006)
    box("gazon",(0,8.2,-.044),(45,14.8,.082),"herbe",o,edge=0)
    box("mur_fond",(-1.04,4.31,1.58),(14,.23,3.16),"mortier",o,edge=.006)
    p=H.Part("parement_brique")
    for row in range(27):
        for i in range(70):
            x=-9+i*.247+(row%2)*.122
            y=4.190
            z=(row+.5)*.101
            w=.235;h=.091
            seq=[p.point(q) for q in ((x-w/2,y,z-h/2),(x+w/2,y,z-h/2),(x+w/2,y,z+h/2),(x-w/2,y,z+h/2))]
            p.face(seq,((0,0),(1,0),(1,1),(0,1)),base("brique_alt" if (i+row*7)%5==0 else "brique"),False)
    attach(p.finish(),o)
    rng=random.Random(4670)
    for i in range(41):
        xx=-9.+i*.4
        yy=rng.uniform(2.42,3.85);zz=rng.uniform(.29,.72)
        if -3.4<xx<-1.7:zz*=.72
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=(xx,yy,zz))
        bush=bpy.context.object
        bush.scale=(rng.uniform(.48,.75),rng.uniform(.48,.73),rng.uniform(.34,.54))
        bush.data.materials.append(base("feuillage_"+str(i%3)))
        for poly in bush.data.polygons:poly.use_smooth=True
    return o

def studio(name,pos,target,scale,w,h,samples=26):
    s=bpy.context.scene
    d=bpy.data.cameras.new('camera')
    cam=bpy.data.objects.new('camera',d);s.collection.objects.link(cam);s.camera=cam
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    d.type='ORTHO';d.ortho_scale=scale
    s.world=bpy.data.worlds.new('ciel_montreal');s.world.use_nodes=True
    b=s.world.node_tree.nodes['Background']
    b.inputs[0].default_value=(.64,.76,.97,1);b.inputs[1].default_value=.41
    sun=bpy.data.lights.new("soleil","SUN")
    sun.energy=2.0;sun.angle=.16;sun.color=(1,.89,.74)
    light=bpy.data.objects.new("soleil",sun);s.collection.objects.link(light)
    light.rotation_euler=Vector((.34,.40,-.81)).to_track_quat("-Z","Y").to_euler()
    H.add_light('reflet_ciel',(2,-4,5),230,(.81,.91,1),4,(.30,0,1))
    s.render.engine='CYCLES';s.cycles.samples=samples;s.cycles.use_denoising=False
    s.view_settings.view_transform='AgX'
    s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100
    s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=93
    s.render.filepath=str(DIR/(name+'.jpg'))
    bpy.ops.render.render(write_still=True)

def street():
    reset("patine")
    environment()
    a=abribus(True);a.location=(-2.05,.142,0)
    b=mailbox();b.location=(2.0,.72,0);b.rotation_euler.z=-.12
    c=bench();c.location=(3.74,-.20,0);c.rotation_euler.z=-.10
    t=rubbish_bin();t.location=(5.03,-.49,0)
    studio("banlieue_assemblage",(8.40,-13.5,6.25),(.47,-.02,1.06),10.85,1540,910,31)

def damaged():
    reset("endommage")
    mat("sol_beton",(.50,.43,.34),.82,texture=texture('beton_base','beton_rough.jpg','beton_normal.jpg'))
    box("sol",(0,0,-.062),(25,25,.12),"sol_beton",H.empty('decor'),edge=0)
    bench().location=(-.87,-.24,0)
    rubbish_bin().location=(.50,.266,0)
    a=mailbox(True);a.location=(1.25,.59,0);a.rotation_euler.z=-.06
    studio("banlieue_usure",(3.6,-7.6,4.2),(.17,.03,.69),4.68,1420,860,32)

def shelter_detail():
    reset("neuf")
    mat("sol_beton",(.50,.43,.34),.82,texture=texture('beton_base','beton_rough.jpg','beton_normal.jpg'))
    box("sol",(0,0,-.062),(25,25,.12),"sol_beton",H.empty('decor'),edge=0)
    abribus(True)
    studio("banlieue_abribus",(5.2,-6.5,2.75),(.19,-.05,1.15),4.72,1260,800,30)

if __name__=='__main__':
    args=sys.argv[sys.argv.index('--')+1:]
    if 'export' in args:
        for make in (abribus,mailbox,bench,rubbish_bin):
            for state in ("neuf","patine","endommage"):
                reset(state)
                export(make())
    if 'bancs' in args:
        for state in ('neuf','patine','endommage'):
            reset(state)
            export(bench())
    if 'rue' in args:street()
    if 'usure' in args:damaged()
    if 'abribus' in args:shelter_detail()
