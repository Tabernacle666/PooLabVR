import bpy
import bmesh
from math import acos, cos, pi, sin, sqrt, tau
from mathutils import Vector
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE / "lots"
MAPS = HERE / "maps"
Z = Vector((0, 0, 1))
FRONT = Vector((0, -1, 0))
X = Vector((1, 0, 0))
Y = Vector((0, 1, 0))

def material(name, color, rough, metal=0, maps=None, alpha=1, emission=None):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, alpha)
    m.use_nodes = True
    m.use_backface_culling = alpha == 1
    ns, links = m.node_tree.nodes, m.node_tree.links
    bsdf = ns.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    if alpha < 1:
        bsdf.inputs["Alpha"].default_value = alpha
        m.surface_render_method = "BLENDED"
        bsdf.inputs["IOR"].default_value = 1.47
    if emission is not None:
        bsdf.inputs["Emission Color"].default_value = (*emission, 1)
        bsdf.inputs["Emission Strength"].default_value = 0
    if maps:
        for index, filename in enumerate(maps):
            image = bpy.data.images.load(str(MAPS / filename), check_existing=True)
            image.colorspace_settings.name = "sRGB" if index == 0 else "Non-Color"
            node = ns.new("ShaderNodeTexImage")
            node.image = image
            if index == 2:
                normal = ns.new("ShaderNodeNormalMap")
                normal.inputs["Strength"].default_value = .68
                links.new(node.outputs["Color"], normal.inputs["Color"])
                links.new(normal.outputs["Normal"], bsdf.inputs["Normal"])
            else:
                links.new(node.outputs["Color"], bsdf.inputs["Base Color" if index == 0 else "Roughness"])
    return m

def empty(name, position=(0,0,0), axis=None, **props):
    o = bpy.data.objects.new(name,None)
    bpy.context.collection.objects.link(o)
    o.location = position
    if axis is not None:
        o.rotation_mode = "QUATERNION"
        # Local -Y becomes +Z on glTF export.
        o.rotation_quaternion = FRONT.rotation_difference(Vector(axis).normalized())
    for key,value in props.items():
        o[key]=value
    return o

class Part:
    def __init__(self, name, pivot=(0,0,0), axis=None, **props):
        self.name, self.pivot = name, Vector(pivot)
        self.rotation = FRONT.rotation_difference(Vector(axis).normalized()) if axis is not None else None
        self.props = props
        self.v, self.faces, self.uvs, self.surfaces, self.smooth = [], [], [], [], []
        self.materials = []

    def point(self,p):
        i = len(self.v)
        relative=Vector(p)-self.pivot
        self.v.append(tuple(self.rotation.inverted() @ relative if self.rotation is not None else relative))
        return i

    def face(self, points, uv, mat, smooth):
        if mat not in self.materials: self.materials.append(mat)
        self.faces.append(tuple(points))
        self.uvs.append(uv)
        self.surfaces.append(self.materials.index(mat))
        self.smooth.append(smooth)

    def finish(self):
        mesh = bpy.data.meshes.new(self.name)
        mesh.from_pydata(self.v,[],self.faces)
        mesh.update()
        uv = mesh.uv_layers.new(name="UV0_METRES")
        for m in self.materials: mesh.materials.append(m)
        for p, coords, slot, smooth in zip(mesh.polygons,self.uvs,self.surfaces,self.smooth):
            p.material_index = slot
            p.use_smooth = smooth
            for loop, pair in zip(p.loop_indices,coords):
                uv.data[loop].uv = pair
        bm=bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method="FIXED")
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()
        obj=bpy.data.objects.new(self.name,mesh)
        bpy.context.collection.objects.link(obj)
        obj.location=self.pivot
        if self.rotation is not None:
            obj.rotation_mode="QUATERNION"
            obj.rotation_quaternion=self.rotation
        for key,value in self.props.items(): obj[key]=value
        return obj

def profile(part, center, axis, rows, mat, sides=48, period=.23, phase=(0.,0.), twist=0):
    """Surface of revolution with UV distances measured on the profile and circumference."""
    c, w = Vector(center), Vector(axis).normalized()
    basis = Z if abs(w.dot(Z)) < .91 else X
    u = (basis-w*basis.dot(w)).normalized()
    v = w.cross(u)
    circles, stations = [], [0.]
    for j,(h,r) in enumerate(rows):
        if j:
            h0,r0=rows[j-1]
            stations.append(stations[-1]+sqrt((h-h0)**2+(r-r0)**2)/period)
        if r <= 1e-10:
            circles.append([part.point(c+w*h)])
        else:
            circles.append([
                part.point(c+w*h+r*(cos(tau*i/sides+twist)*u+sin(tau*i/sides+twist)*v))
                for i in range(sides)
            ])
    for j,(ra,rb) in enumerate(zip(circles,circles[1:])):
        shade=mat[j] if isinstance(mat,list) else mat
        smooth = sides>=12 and abs(rows[j+1][0]-rows[j][0]) > .00001
        for i in range(sides):
            k=(i+1)%sides
            def uv(angle_index, edge):
                r = rows[edge][1]/period
                angle = tau*angle_index/sides
                if abs(rows[j+1][0]-rows[j][0]) < 1e-6:
                    return (r*cos(angle+twist)+phase[0],r*sin(angle+twist)+phase[1])
                return ((angle-pi)*r+phase[0],stations[edge]+phase[1])
            if len(ra)==1:
                part.face((ra[0],rb[k],rb[i]),(uv(i+.5,j),uv(i+1,j+1),uv(i,j+1)),shade,smooth)
            elif len(rb)==1:
                part.face((ra[i],ra[k],rb[0]),(uv(i,j),uv(i+1,j),uv(i+.5,j+1)),shade,smooth)
            else:
                part.face((ra[i],ra[k],rb[k],rb[i]),(uv(i,j),uv(i+1,j),uv(i+1,j+1),uv(i,j+1)),shade,smooth)

def collar(part, center, axis, h, r, mat, n=36, edge=.002):
    e=min(edge,h*.22,r*.18)
    profile(part,center,axis,[(0,0),(0,r-e),(e,r),(h-e,r),(h,r-e),(h,0)],mat,n)

def annulus(part, center, axis, h, ro, ri, mat, n=36):
    profile(part,center,axis,[(0,ro),(.001,ro+.001),(h-.001,ro+.001),(h,ro),
                              (h,ri),(0,ri),(0,ro)],mat,n)

def bolt(part, pos, axis, radius, height, mat, washer=None):
    a,c = Vector(axis),Vector(pos)
    if washer is not None: annulus(part,c,a,.0025,radius*1.24,radius*.62,washer,16)
    c += a*.002
    profile(part,c,a,[(0,0),(0,radius*.90),(.001,radius),(height-.001,radius),
                      (height,radius*.85),(height,0)],mat,6)

def add_light(name, pos, energy, color, size, aim):
    data=bpy.data.lights.new(name,"AREA")
    data.energy,data.color,data.shape,data.size=energy,color,"DISK",size
    o=bpy.data.objects.new(name,data)
    bpy.context.collection.objects.link(o)
    o.location=pos
    o.rotation_euler=(Vector(aim)-o.location).to_track_quat("-Z","Y").to_euler()

