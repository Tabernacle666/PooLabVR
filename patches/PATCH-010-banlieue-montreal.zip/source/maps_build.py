from pathlib import Path
import math
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

root=Path(__file__).parent/'maps'
rng=np.random.default_rng(9019)
n=768
y,x=np.mgrid[:n,:n]/n

def noise(sigma):
    ar=gaussian_filter(rng.normal(size=(n,n)),sigma,mode='wrap')
    return ar/ar.std()

def save(name,a,quality=91):
    Image.fromarray(np.clip(np.round(a*255),0,255).astype('uint8')).save(root/(name+'.jpg'),quality=quality,subsampling=0)

wood=np.asarray(Image.open(root/'wood_base.jpg').resize((n,n)))/255
intensity=wood@np.array([.29,.59,.12])
grain=np.clip(.65+intensity-.21,.43,1.07)
slow=noise(36);mid=noise(8);fine=noise(.9)
scar=np.clip(.35*noise((20,1.5))+.24*slow-.08,0,.84)
raw=np.clip(wood*1.3+.070,0,1)
save('bois_miel',raw*np.array([1.05,1.015,.96]))
save('bois_grise',(.43*raw+.32*intensity[...,None]+.115)*(1+.085*slow+.047*mid)[...,None])
green=grain[...,None]*np.array([.248,.365,.277])
save('vert',green*(1+.046*fine+.012*mid)[...,None])
save('vert_use',green*(1-scar[...,None])+(raw*.71+.10)*scar[...,None])
base=np.stack([.54+.013*slow+.006*fine,.57+.014*slow+.006*fine,.59+.015*slow+.006*fine],axis=-1)
brushed=noise((18,.97))
save('alu',base+.010*brushed[...,None])
save('alu_use',(base+.016*brushed[...,None])*(.93+.051*slow+.033*mid)[...,None])
paint=np.stack([.658+.010*fine,.674+.010*fine,.662+.010*fine],axis=-1)
dirt=np.clip(.22+.125*slow+.105*noise((17,4)),0,.69)
save('gris_poste',paint)
save('gris_poste_use',paint*(1-.42*dirt[...,None])+np.array([.085,.082,.048])*dirt[...,None])
iron=np.stack([.116+.008*fine,.137+.008*fine,.132+.008*fine],axis=-1)
save('fer',iron)
pits=np.clip(.50*noise(4)+.29*slow-.31,0,1)[...,None]
save('fer_use',iron*(1-pits)+pits*np.array([.45,.255,.137]))
rough=.62+.037*mid+.023*fine
save('metal_rough',rough)
height=.23*brushed+.17*fine+.105*mid
dx=(np.roll(height,1,1)-np.roll(height,-1,1))*.26
dy=(np.roll(height,-1,0)-np.roll(height,1,0))*.26
save('metal_normal',np.stack((dx,dy,np.ones_like(dx)),axis=-1)/np.sqrt(dx*dx+dy*dy+1)[...,None]*.5+.5,96)
streak=np.clip((noise((24,1))-.35)*.037+(noise((12,4))+.4)*.009,0,.10)
rgba=np.zeros((n,n,4),dtype='uint8')
rgba[:,:,:3]=(194,206,194)
rgba[:,:,3]=np.clip((.077+streak)*255,0,255).astype('uint8')
Image.fromarray(rgba).save(root/'verre_use.png',optimize=True)

# Original mock advertisement. A caption-safe portrait texture with an authored layout.
W,H=720,1280
im=Image.new('RGB',(W,H),(22,47,53))
d=ImageDraw.Draw(im)
from PIL import ImageFont
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def txt(pt,label,px,color):d.text(pt,label,font=ImageFont.truetype(font,px),fill=color)
for j in range(445,H):
    t=(j-445)/(H-445)
    d.line((0,j,W,j),fill=tuple(round(a+(b-a)*t) for a,b in zip((25,64,62),(44,114,87))))
d.ellipse((440,391,630,581),fill=(249,185,89))
for k,col in enumerate(((28,66,66),(22,80,76),(18,91,75),(16,62,53))):
    pts=[(q, int(662+82*k+58*math.cos(q/152+k)+14*math.sin(q/46+k))) for q in range(0,731,10)]
    d.polygon(pts+[(730,H),(0,H)],fill=col)
d.line((56,73,163,73),fill=(242,191,104),width=5)
txt((56,104),'OASIS  /  PARCS',28,(232,224,192))
txt((49,200),'PRENEZ',105,(252,239,206))
txt((49,322),'L’AIR.',124,(252,239,206))
txt((50,1135),'SAMEDI  •  AU PARC',32,(252,239,206))
im.save(root/'pub_oasis.jpg',quality=95,subsampling=0)
