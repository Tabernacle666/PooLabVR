from pathlib import Path
import math
import sys
import random
import bpy
import bmesh
from mathutils import Vector

DIR = Path(__file__).parent.resolve()
sys.path.insert(0,str(DIR))
import helpers as H
H.MAPS = DIR / 'maps'

WALL_H=2.4384
STUD=.038
WALL_T=.089
BOARD=.0127
SPACING=.4064
STILE=.046
DOOR_H=2.032
STEP_RISE=.180
STEP_RUN=.260
STAIR_W=.914
RAIL_TOP=.762
DOORS=(.762,.813,.914)
WINDOWS=((.914,.914),(1.219,.914),(1.524,1.067))
FLOORS=(.05715,.08255,.127)
Z=Vector((0,0,1))
F=Vector((0,-1,0))
X=Vector((1,0,0))
WOOD_PERIOD=(.59,.62)

COLONIAL=[(0,0),(0,.009),(.06,.013),(.17,.013),(.24,.009),(.34,.009),(.38,.012),
          (.45,.016),(.56,.019),(.68,.021),(.87,.023),(.97,.022),(1,.018),(1,0)]
PLAIN=[(0,0),(0,.014),(.03,.017),(.15,.019),(.90,.019),(.97,.018),(1,.015),(1,0)]
BASE=[(0,0),(0,.015),(.04,.017),(.72,.017),(.78,.016),(.84,.014),(.87,.011),
      (.90,.010),(.93,.010),(.97,.009),(1,.006),(1,0)]
RAIL=[(0,0),(0,.011),(.075,.014),(.15,.012),(.24,.012),(.32,.015),(.42,.020),
      (.53,.023),(.65,.022),(.76,.018),(.84,.014),(.96,.014),(1,.011),(1,0)]
SHOE=[(0,0),(0,.013),(.10,.014),(.37,.0135),(.60,.011),(.81,.0075),(.94,.004),(1,0)]

def bsdf(mat):
    return mat.node_tree.nodes.get('Principled BSDF')

def use_map(mat,name,input,normal=False,strength=.52,color=True):
    nodes=mat.node_tree.nodes
    links=mat.node_tree.links
    image=nodes.new('ShaderNodeTexImage')
    image.image=bpy.data.images.load(str(H.MAPS/name),check_existing=True)
    image.image.colorspace_settings.name='sRGB' if color else 'Non-Color'
    signal=image.outputs["Color"]
    if normal:
        normal_node=nodes.new('ShaderNodeNormalMap')
        normal_node.inputs["Strength"].default_value=strength
        links.new(signal,normal_node.inputs["Color"])
        signal=normal_node.outputs["Normal"]
    links.new(signal,bsdf(mat).inputs[input])

def tint(mat,color):
    nodes=mat.node_tree.nodes;links=mat.node_tree.links
    dst=bsdf(mat).inputs['Base Color']
    src=dst.links[0].from_socket
    mult=nodes.new('ShaderNodeMixRGB')
    mult.blend_type='MULTIPLY';mult.inputs[0].default_value=1
    mult.inputs[2].default_value=(*color,1)
    links.new(src,mult.inputs[1]);links.new(mult.outputs[0],dst)
    return mat

def init():
    global paint, gypsum, face, back_paper, raw, clear, spacer, rubber, wood, art, brass, white, maple, dark, kraft
    bpy.ops.wm.read_factory_settings(use_empty=True)
    wood_maps=('wood_base.jpg','wood_rough.jpg','wood_normal.jpg')
    paint=H.material('boiserie_ivoire_satin',(.77,.73,.652),.48)
    white=H.material('chassis_blanc_casse',(.80,.79,.74),.34)
    gypsum=H.material('ame_gypse',(.82,.80,.74),.94)
    use_map(gypsum,'gypse_brut.jpg','Base Color')
    use_map(gypsum,'gypse_normal.jpg','Normal',True,.65,False)
    face={}
    for name,color in (('lin',(.65,.60,.50)),('sauge',(.393,.465,.375)),('coquille',(.83,.81,.749))):
        mat=H.material('gypse_peinture_'+name,color,.81)
        use_map(mat,'gypse_normal.jpg','Normal',True,.32,False)
        face[name]=mat
    back_paper=H.material('papier_dos_gypse',(.32,.255,.177),.91)
    raw=tint(H.material('bois_charpente_clair',(.65,.51,.36),.62,maps=wood_maps),(1.17,1.14,1.04))
    wood=tint(H.material('bois_chene_miel',(.46,.27,.12),.45,maps=wood_maps),(1.08,1.00,.86))
    maple=tint(H.material('bois_erable_clair',(.62,.51,.32),.37,maps=wood_maps),(1.20,1.16,1.12))
    dark=tint(H.material('bois_teinte_noyer',(.23,.116,.057),.46,maps=wood_maps),(.54,.45,.40))
    rubber=H.material('joint_etanche',(.036,.035,.030),.78)
    brass=H.material('laiton_brosse',(.43,.272,.103),.32,.76)
    spacer=H.material('intercalaire_aluminium',(.51,.52,.53),.35,.72)
    clear=H.material('verre_clair_alpha',(.67,.80,.83),.11,alpha=.066)
    clear.use_backface_culling=True
    art=H.material('illustration_originale',(.42,.49,.55),.75)
    use_map(art,'photo.jpg','Base Color')
    kraft=H.material('passe_partout_creme',(.76,.70,.59),.9)

def front_uv(co, grain, offset=(0,0), period=WOOD_PERIOD):
    a,b,c=co
    length={'x':a,'y':b,'z':c}[grain]
    if grain=='x': across=b+c
    elif grain=='y': across=a+c
    else: across=a+b
    return (across/period[0]+offset[0],length/period[1]+offset[1])

def attach(obj,parent):
    obj.parent=parent
    return obj

def metadata(obj, **info):
    for k,v in info.items():obj[k]=v
    return obj

def profile_id(mat):
    if mat == clear:return 'glass'
    if mat in (spacer,brass): return 'metal'
    if mat in (gypsum,back_paper,*face.values()): return 'plaster'
    if mat == rubber: return 'rubber'
    return 'wood'

def block(name,c,dimensions,mat,root,grain='z',edge=.0011,offset=(0,0),layered=False,photo=False):
    bpy.ops.mesh.primitive_cube_add(size=1,location=c)
    o=bpy.context.object;o.name=name
    o.dimensions=dimensions
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.clear()
    for m in ((gypsum,mat,back_paper) if layered else (mat,)):o.data.materials.append(m)
    if layered:
        for p in o.data.polygons:
            p.material_index=1 if p.normal.y<-.5 else 2 if p.normal.y>.5 else 0
    if edge:
        mod=o.modifiers.new('rayon_usine','BEVEL');mod.width=edge;mod.segments=2
        bpy.ops.object.modifier_apply(modifier=mod.name)
    tri=o.modifiers.new('triangles','TRIANGULATE')
    bpy.ops.object.modifier_apply(modifier=tri.name)
    uv=o.data.uv_layers.active
    for p in o.data.polygons:
        nx,ny,nz=p.normal
        for idx in p.loop_indices:
            a,b,d=o.data.vertices[o.data.loops[idx].vertex_index].co
            xyz=(a,b,d)
            axis=max(range(3),key=lambda j:abs((nx,ny,nz)[j]))
            plane=[j for j in range(3) if j!=axis]
            grain_axis={'x':0,'y':1,'z':2}[grain]
            if photo and axis==1:
                coords=(a/dimensions[0]+.5,d/dimensions[2]+.5)
            elif layered:
                coords=tuple(xyz[j]/.32 for j in plane)
            else:
                if grain_axis in plane:
                    plane.remove(grain_axis)
                    plane.append(grain_axis)
                coords=tuple(xyz[j]/WOOD_PERIOD[k]+offset[k] for k,j in enumerate(plane))
            uv.data[idx].uv=coords
    return metadata(attach(o,root),component_id=name,material_profile='plaster' if layered else profile_id(mat))

def railing(name,path,y,profile,width,mat,root,closed=False,flip_y=False):
    part=H.Part(name,component_id=name,material_profile=profile_id(mat))
    path=[Vector(p) for p in path]
    count=len(path)
    directions=[(path[(i+1)%count]-path[i]).normalized() for i in range(count if closed else count-1)]
    normals=[Vector((-v[1],v[0])) for v in directions]
    rings=[]
    lengths=[0.]
    for i in range(count-1): lengths.append(lengths[-1]+(path[i+1]-path[i]).length)
    for i,p in enumerate(path):
        if i==0 and not closed: v=normals[0]
        elif i==count-1 and not closed: v=normals[-1]
        else:
            n1,n2=normals[i-1],normals[i%len(normals)]
            v=(n1+n2)/(1+n1.dot(n2))
        ring=[]
        for t,d in profile:
            xx,zz=p+v*(t*width)
            ring.append(part.point((xx,y+d*(1 if flip_y else -1),zz)))
        rings.append(ring)
    n=len(profile)
    for i in range(len(directions)):
        k=(i+1)%count
        length0=lengths[i]
        length1=lengths[k] if k else lengths[-1]+(path[-1]-path[0]).length
        for j in range(n):
            a=(j+1)%n
            def uv(i,s):
                t,d=profile[i]
                return (t*width/WOOD_PERIOD[0]+d/WOOD_PERIOD[0],s/WOOD_PERIOD[1])
            part.face((rings[i][j],rings[k][j],rings[k][a],rings[i][a]),
                      (uv(j,length0),uv(j,length1),uv(a,length1),uv(a,length0)),mat,False)
    if not closed:
        uv=[(t*width/WOOD_PERIOD[0],d/WOOD_PERIOD[1]) for t,d in profile]
        part.face(rings[0][::-1],uv[::-1],mat,False)
        part.face(rings[-1],uv,mat,False)
    obj=part.finish()
    bm=bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data)
    bm.free()
    return attach(obj,root)

def surround(name,x,z,w,height,y,prof,width,mat,root,door=False,far=False):
    path=[(x-w/2,z),(x-w/2,z+height),(x+w/2,z+height),(x+w/2,z)]
    return railing(name,path,y,prof,width,mat,root,not door,far)

def line(name,length,z,y,prof,width,mat,parent):
    return railing(name,[(0,z),(length,z)],y,prof,width,mat,parent)

def root(name,**props):
    return H.empty(name,asset_id='oasis_boiseries_residentielles',variant=name,**props)

def socket(owner,name,point,**kwargs):
    return attach(H.empty(name,point,role='socket',**kwargs),owner)

def pane(name,center,w,z,t,parent):
    return metadata(block(name,center,(w,t,z),clear,parent,edge=0),role="glazing",epaisseur_m=t)

def frame_bars(name,x,z,w,height,y,width,depth,mat,parent):
    for side in (-1,1):
        tag='G' if side<0 else 'D'
        block(name+'_montant_'+tag,(x+side*(w-width)/2,y,z+height/2),(width,depth,height),mat,parent)
    for top,at in [('bas',z+width/2),('haut',z+height-width/2)]:
        block(name+'_traverse_'+top,(x,y,at),(w-2*width,depth,width),mat,parent,grain='x')

def window(w,height,style):
    ident=f'fenetre_{round(w*1000)}x{round(height*1000)}_{style}'
    o=root(ident,rough_width_m=w+.020,rough_height_m=height+.020,unit_width_m=w,unit_height_m=height)
    trim=paint if style=='colonial' else wood
    sash=white if style=='colonial' else wood
    prof=COLONIAL if style=='colonial' else PLAIN
    frame_bars('dormant',0,0,w,height,0,.042,WALL_T+2*BOARD,sash,o)
    old_y=-(WALL_T/2+BOARD)
    surround('chambranle',0,0,w,height,old_y,prof,.0635,trim,o)
    block('tablette_de_fenetre',(0,old_y-.022,-.018),(w+.171,.112,.032),trim,o,grain='x',edge=.003)
    line('tablier_gauche_origine',w+.110,-.097,old_y,prof,.050,trim,
         attach(H.empty('appui_tablier',(-w/2-.055,0,0)),o))
    inside_w=w-.092
    side_w=inside_w*.50
    for side in (-1,1):
        side_name='ouvrant' if side<0 else 'fixe'
        x=side*side_w/2
        child=attach(H.empty(side_name,(x,.023*side,0),component_id=side_name,operable=side<0,
                             translation_axis='+X',course_m=side_w-.060 if side<0 else 0.),o)
        frame_bars('vantail_'+side_name,0,.045,side_w+.008,height-.090,0,STILE,.039,sash,child)
        gw=side_w+.008-2*STILE
        gh=height-.090-2*STILE
        pane('verre_interieur',(0,-.008,height/2),gw,gh,.004,child)
        pane('verre_exterieur',(0,.008,height/2),gw,gh,.004,child)
        frame_bars('intercalaire',0,(height-gh)/2,gw,gh,0,.006,.012,spacer,child)
        frame_bars('joint_vitrage',0,(height-gh)/2-.003,gw+.006,gh+.006,-.012,.006,.004,rubber,child)
        if side<0:
            block('loquet',(side_w/2-.023,-.031,height*.522),(.034,.029,.049),brass,child)
    socket(o,'baie', (0,0,0))
    socket(o,'axe_pose_haut',(0,0,height))
    return o

def hardware(name,c,mat,parent,shape='knob'):
    p=H.Part(name,c,component_id=name,material_profile='metal')
    rows=[(0,0),(0,.032),(.004,.033),(.008,.017),(.030,.014),(.033,.024),
          (.043,.027),(.055,.024),(.062,.011),(.063,0)]
    H.profile(p,c,F,rows,mat,24)
    return attach(p.finish(),parent)

def door(w,style):
    o=root(f'porte_{round(w*1000)}_{style}',vantail_largeur_m=w,vantail_hauteur_m=DOOR_H,
           rough_width_m=w+.050,rough_height_m=DOOR_H+.055,hand='gauche')
    trim=paint if style=='colonial' else wood
    vmat=paint if style=='colonial' else wood
    prof=COLONIAL if style=='colonial' else PLAIN
    inner=w+.006
    high=DOOR_H+.011
    y=-(WALL_T/2+BOARD)
    for side in (-1,1):
        tag='G' if side<0 else 'D'
        block('jambage_'+tag,(side*(inner/2+.0095),0,high/2),(.019,WALL_T+2*BOARD,high),trim,o)
        block('butee_'+tag,(side*(inner/2-.0045),.020,high/2),(.010,.014,high),trim,o)
    block('jambage_haut',(0,0,high+.0095),(inner+.038,WALL_T+2*BOARD,.019),trim,o,grain='x')
    block('butee_haute',(0,.020,high-.005),(inner,.014,.010),trim,o,grain='x')
    surround('chambranle_interieur',0,0,inner+.014,high+.007,y,prof,.066,trim,o,door=True)
    surround('chambranle_exterieur',0,0,inner+.014,high+.007,-y,prof,.066,trim,o,door=True,far=True)
    leaf=attach(H.empty('vantail',(-w/2,-.009,.008),component_id='vantail',axis_local='+Y',angle_deg=103),o)
    for xx in (.057,w-.057):
        block('montant_vantail',(xx,0,DOOR_H/2),(.114,.035,DOOR_H),vmat,leaf)
    for zz,t in ((.076,.152),(.918,.101),(DOOR_H-.052,.104)):
        block('traverse_vantail',(w/2,0,zz),(w-.228,.035,t),vmat,leaf,grain='x')
    for j,(lo,hi) in enumerate(((.149,.870),(.968,DOOR_H-.101))):
        span=w-.224
        block('panneau_ame',(w/2,.001,(lo+hi)/2),(span,.021,hi-lo),vmat,leaf,edge=.0024)
        if style=='colonial':
            surround('moulure_panneau_'+str(j),w/2,lo+.026,span-.051,hi-lo-.052,-.013,
                     [(r,d*.44) for r,d in PLAIN],.033,vmat,leaf)
    hardware('poignee',(w-.074,-.019,1.003),brass,leaf)
    knob=hardware('poignee_face_cachee',(w-.074,.019,1.003),brass,leaf)
    knob.rotation_euler.z=math.pi
    for z in (.230,1.008,1.794):
        p=H.Part('fiche_charniere',(0,-.020,z),material_profile='metal')
        H.collar(p,(0,-.020,z),Z,.069,.0065,brass,16)
        attach(p.finish(),leaf)
    socket(o,'baie',(0,0,0))
    return o

def trim_piece(style,name):
    m=paint if style=='colonial' else wood
    profiles={
        'plinthe': (0,BASE if style=='colonial' else PLAIN,.10795),
        'quart_de_rond': (0,SHOE,.016),
        'cimaise_30po': (RAIL_TOP-.061,RAIL if style=='colonial' else PLAIN,.061),
        'chambranle_stock': (0,COLONIAL if style=='colonial' else PLAIN,.066),
    }
    z,profile,width=profiles[name]
    o=root(name+'_'+style,length_m=2.4384,role='linear_trim',height_m=width,
           anchor_height_m=z)
    line('profil_'+name,2.4384,0,0,profile,width,m,o)
    socket(o,'debut',(0,0,0));socket(o,'fin',(2.4384,0,0))
    return o

def gypsum_panel(width,color):
    o=root(f'gypse_{round(width*1000)}_{color}',width_m=width,height_m=WALL_H,thickness_m=BOARD,paint=color)
    block('panneau_gypse',(width/2,0,WALL_H/2),(width,BOARD,WALL_H),face[color],o,edge=.00085,layered=True)
    socket(o,'debut',(0,0,0));socket(o,'fin',(width,0,0))
    return o

def framing(kind):
    width=SPACING*3
    o=root('ossature_'+kind,module_width_m=width,finished_floor_to_ceiling_m=WALL_H,stud_spacing_m=SPACING,
           stud_width_m=STUD,stud_depth_m=WALL_T)
    for zz in (STUD/2,WALL_H-STUD*.5,WALL_H-STUD*1.5):
        block('lisse',(width/2,0,zz),(width,WALL_T,STUD),raw,o,grain='x')
    bottom=STUD;top=WALL_H-2*STUD
    if kind=='nu':
        for i in range(4):
            stud_x = STUD*.5 if i==0 else width-STUD*.5 if i==3 else i*SPACING
            block('montant',(stud_x,0,(bottom+top)/2),(STUD,WALL_T,top-bottom),raw,o,offset=(.09*i,.22*i))
    elif kind=='baie_fenetre':
        opening=WINDOWS[0][0]+.020
        height=WINDOWS[0][1]+.020
        sill=.920
        x0=(width-opening)/2
        for side in (-1,1):
            x=width/2+side*(opening/2+STUD*1.5)
            block('montant_continu',(x,0,(bottom+top)/2),(STUD,WALL_T,top-bottom),raw,o)
            x=width/2+side*(opening/2+STUD*.5)
            block('montant_appui',(x,0,(bottom+sill+height)/2),(STUD,WALL_T,sill+height-bottom),raw,o)
        block('appui_brut',(width/2,0,sill-STUD/2),(opening,WALL_T,STUD),raw,o,grain='x')
        block('linteau_visuel',(width/2,0,sill+height+.070),(opening+2*STUD,WALL_T,.140),raw,o,grain='x')
        for y in (width/3,2*width/3):
            block('montant_allege',(y,0,(STUD+sill-STUD)/2),(STUD,WALL_T,sill-2*STUD),raw,o)
            segment_top=sill+height+.140
            block('montant_court_haut',(y,0,(top+segment_top)/2),(STUD,WALL_T,top-segment_top),raw,o)
        socket(o,'baie_fenetre',(x0+opening/2,0,sill),rough_width_m=opening,rough_height_m=height)
    socket(o,'debut',(0,0,0));socket(o,'fin',(width,0,0))
    return o

def beam():
    o=root('poutre_apparente_140x235',length_m=2.4384,section_m=[.140,.235])
    block('bois_poutre',(1.2192,0,0),(2.4384,.140,.235),wood,o,grain='x',edge=.0040)
    socket(o,'debut',(0,0,0));socket(o,'fin',(2.4384,0,0))
    return o

def stair_piece():
    o=root('pas_escalier',width_m=STAIR_W,rise_m=STEP_RISE,run_m=STEP_RUN,nez_m=.023)
    block('contremarche',(0,.008,STEP_RISE/2),(STAIR_W,.016,STEP_RISE),paint,o,grain='x')
    block('marche_nez_rapporte',(0,(STEP_RUN-.023)/2,STEP_RISE-.018),(STAIR_W,STEP_RUN+.023,.036),
          wood,o,grain='x',edge=.006)
    socket(o,'depart',(0,0,0));socket(o,'marche_suivante',(0,STEP_RUN,STEP_RISE))
    return o

def staircase(count=15):
    treads=count-1
    o=root(f'volee_escalier_{count}_hauteurs',rise_m=STEP_RISE,run_m=STEP_RUN,story_height_m=count*STEP_RISE,
           finished_width_m=STAIR_W,treads=treads)
    for i in range(count):
        unit=attach(H.empty('pas_%02d'%(i+1),(0,STEP_RUN*i,STEP_RISE*i)),o)
        block('contremarche',(0,.008,STEP_RISE/2),(STAIR_W,.016,STEP_RISE),paint,unit,grain='x')
        if i<treads:
            block('marche',(0,(STEP_RUN-.023)/2,STEP_RISE-.018),(STAIR_W,STEP_RUN+.023,.036),
                  wood,unit,grain='x',edge=.006)
    socket(o,'palier_bas',(0,0,0));socket(o,'palier_haut',(0,STEP_RUN*treads,count*STEP_RISE))
    steps=[]
    for i in range(treads):
        z=(i+1)*STEP_RISE-.036
        steps.extend(((i*STEP_RUN+.022,z),(min(treads*STEP_RUN,(i+1)*STEP_RUN+.022),z)))
    steps.extend(((treads*STEP_RUN,treads*STEP_RISE-.219),(.101,0),(.022,0)))
    for x in (-STAIR_W*.38,STAIR_W*.38):
        p=H.Part('limon_a_cremaillere',material_profile='wood')
        rings=[[p.point((x+d,y,z)) for y,z in steps] for d in (-.019,.019)]
        uv=[(y/WOOD_PERIOD[0],z/WOOD_PERIOD[1]) for y,z in steps]
        p.face(rings[0],uv,raw,False)
        p.face(rings[1][::-1],uv[::-1],raw,False)
        for i in range(len(steps)):
            j=(i+1)%len(steps)
            length=math.dist(steps[i],steps[j])/WOOD_PERIOD[1]
            p.face((rings[0][i],rings[1][i],rings[1][j],rings[0][j]),
                   ((0,0),(.038/WOOD_PERIOD[0],0),(.038/WOOD_PERIOD[0],length),(0,length)),raw,False)
        attach(p.finish(),o)
    return o

def hardwood(width,style, demo=False):
    mat=wood if style=='miel' else maple
    length=2.4384
    o=root(f'parquet_{round(width*10000):04d}_{style}',board_width_m=width,thickness_m=.01905,
           tile_length_m=length,board_seam_m=.0009,board_grain='+Z')
    nx=round(1.213/width) if not demo else round(5.28/width)
    deep=length if not demo else 3.8
    rng=random.Random(81453+round(width*10000))
    # Merge planks as a mesh while carrying per-board grain phase and mitered arrises.
    part=H.Part('parquet_joint_decale',material_profile='wood',role='floor')
    e=.00075
    for i in range(nx):
        y=0.
        cells=[]
        while y < deep-1e-7:
            segment=min(rng.uniform(.40,1.31),deep-y)
            if 0<deep-y-segment<.29:segment=deep-y
            cells.append((y,y+segment));y+=segment
        for a,b in cells:
            x1=i*width+.00045
            x2=(i+1)*width-.00045
            a+=.00045;b-=.00045
            indices=[]
            phase=(rng.random(),rng.random())
            for z,s in ((-.01905,0),(-e,0),(0,e)):
                indices.append([part.point(p) for p in ((x1+s,a+s,z),(x2-s,a+s,z),(x2-s,b-s,z),(x1+s,b-s,z))])
            faces=[indices[0][::-1],indices[-1]]
            for low,high in zip(indices,indices[1:]):
                for j in range(4): faces.append((low[j],low[(j+1)%4],high[(j+1)%4],high[j]))
            for f in faces:part.face(f,[front_uv(part.v[u],'y',phase) for u in f],mat,False)
    attach(part.finish(),o)
    socket(o,'debut',(0,0,0));socket(o,'fin',(0,deep,0))
    metadata(o,tile_width_m=nx*width)
    return o

def single_board(width,style):
    mat=wood if style=='miel' else maple
    o=root(f'latte_{round(width*10000):04d}_{style}',board_width_m=width,length_m=.9144,thickness_m=.01905)
    block('latte_bois_franc',(width/2,.4572,-.009525),(width,.9144,.01905),mat,o,grain='y',edge=.0008)
    socket(o,'debut',(0,0,0));socket(o,'fin',(0,.9144,0))
    return o

def photo(style):
    mat=dark if style=='noyer' else wood
    o=root('cadre_photo_'+style,outer_width_m=.344,outer_height_m=.271,photo_width_m=.254,photo_height_m=.1905)
    ow,oh=.344,.271
    surround('cadre_bois_onglets',0,-oh/2+.027,ow-.054,oh-.054,0,RAIL if style=='noyer' else PLAIN,.027,mat,o)
    block('fond_cadre',(0,.006,0),(ow-.024,.007,oh-.024),raw,o,grain='x')
    block('passe_partout',(0,.0005,0),(ow-.050,.003,oh-.050),kraft,o,edge=.0004)
    block('tirage',(0,-.0015,0),(.254,.001,.1905),art,o,edge=0,photo=True)
    pane('verre_photo',(0,-.004,0),ow-.054,oh-.054,.002,o)
    socket(o,'accroche',(0,.013,oh/2-.047))
    return o

def save(o):
    base=DIR/'kit'
    base.mkdir(exist_ok=True)
    bpy.ops.export_scene.gltf(filepath=str(base/(o.name+'.gltf')),export_format='GLTF_SEPARATE',
                              export_yup=True,export_texture_dir='textures',export_extras=True,export_tangents=True)

def products():
    yield lambda: beam()
    yield lambda: stair_piece()
    yield lambda: staircase(14)
    yield lambda: staircase(15)
    yield lambda: framing('nu')
    yield lambda: framing('baie_fenetre')
    for sty in ('colonial','droit'):
        for name in ('plinthe','quart_de_rond','cimaise_30po','chambranle_stock'):
            yield lambda sty=sty,name=name: trim_piece(sty,name)
        for w in DOORS:
            yield lambda w=w,sty=sty: door(w,sty)
        for w,height in WINDOWS:
            yield lambda w=w,height=height,sty=sty: window(w,height,sty)
    for col in ('lin','sauge','coquille'):
        yield lambda col=col: gypsum_panel(1.2192,col)
    for width in FLOORS:
        for style in ('miel','clair'):
            yield lambda width=width,style=style: single_board(width,style)
            yield lambda width=width,style=style: hardwood(width,style)
    for style in ('noyer','miel'):
        yield lambda style=style: photo(style)

def studio(name,pos,target,scale,width,height,samples=30):
    s=bpy.context.scene
    d=bpy.data.cameras.new('camera')
    cam=bpy.data.objects.new('camera',d);s.collection.objects.link(cam);s.camera=cam
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    d.type='ORTHO';d.ortho_scale=scale
    s.world=bpy.data.worlds.new('ciel');s.world.use_nodes=True
    b=s.world.node_tree.nodes['Background']
    b.inputs[0].default_value=(.52,.65,.80,1);b.inputs[1].default_value=.28
    H.add_light('lumiere_fenetre',(.20,1.51,2.20),260,(.80,.89,1),1.65,(.8,-1.2,.70))
    H.add_light('interieur',(-2.6,-3.7,3.85),515,(1,.89,.72),3.6,(.45,0,1.12))
    H.add_light('rebond_doux',(3,-1.3,2.6),170,(1,.92,.82),2.1,(0,0,1.1))
    s.render.engine='CYCLES';s.cycles.samples=samples;s.cycles.use_denoising=False
    s.view_settings.view_transform='AgX'
    s.render.resolution_x=width;s.render.resolution_y=height
    s.render.resolution_percentage=100;s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=92
    s.render.filepath=str(DIR/(name+'.jpg'))
    bpy.ops.render.render(write_still=True)

def walls(width, dcenter,wcenter, ty, parent):
    dh=DOOR_H+.02
    wz=.91;ww=1.219;wh=.914
    spans=[(-2.62,dcenter-.424,0,WALL_H),(dcenter+.424,wcenter-ww/2,0,WALL_H),(wcenter+ww/2,width,0,WALL_H),
           (dcenter-.424,dcenter+.424,dh,WALL_H),
           (wcenter-ww/2,wcenter+ww/2,0,wz),
           (wcenter-ww/2,wcenter+ww/2,wz+wh,WALL_H)]
    for l,r,b,t in spans:
        if r>l:
            block('mur_sauge',((r+l)/2,ty,(t+b)/2),(r-l,BOARD,t-b),face['sauge'],parent,layered=True,edge=0)

def scene_house(detail=False):
    init()
    base=hardwood(.08255,'miel',demo=True);base.location=(-2.68,-3.03,0)
    wall=root('mur_demo')
    walls(1.74,-1.82,.08,-.0508,wall)
    d=door(.813,'colonial');d.location=(-1.82,0,0)
    w=window(1.219,.914,'colonial');w.location=(.08,0,.91)
    stack=attach(H.empty('zones_ossature',(1.74,0,0)),wall)
    for i in range(5):
        xx=i*(SPACING*.52)
        block('montant_visible',(xx,0,WALL_H/2),(.038,WALL_T,WALL_H-.076),raw,stack,offset=(i*.14,i*.23))
    for zz in (.019,WALL_H-.019):
        block('lisse_visible',(.42,0,zz),(.88,.089,.038),raw,stack,grain='x')
    for a,b in ((-2.62,-2.312),(-1.325,1.74)):
        parent=H.empty('ligne_boiserie',(a,0,0))
        line('plinthe',b-a,.002,-.057,BASE,.108,paint,parent)
        line('cimaise',b-a,RAIL_TOP-.061,-.057,RAIL,.061,paint,parent)
    p=photo('noyer');p.location=(-.858,-.073,1.409)
    p=photo('miel');p.location=(1.187,-.073,1.53)
    o=beam();o.location=(-2.63,-.13,2.32)
    o=staircase();o.location=(2.135,-2.67,0)
    # Window background with original silhouettes to give glazing useful contrast.
    bg=H.material('jardin_apercu',(.205,.302,.203),.94)
    sky=H.material('ciel_apercu',(.48,.61,.70),.95)
    outside=H.empty('fond_apercu')
    block('ciel',(0,1.6,1.80),(5,.04,2.6),sky,outside)
    for i in range(11):
        rng=random.Random(i+35)
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=.5,location=(-2.9+.42*i,1.26,rng.uniform(.64,1.41)))
        bush=bpy.context.object;bush.scale=(.85,.26,rng.uniform(.80,1.42));bush.data.materials.append(bg)
    if detail:
        studio('apercu_fenetre',(-.50,-1.75,1.77),(.095,.00,1.215),1.70,1120,850,36)
    else:
        studio('apercu_maison',(4.8,-7.2,3.65),(0,-.65,1.04),7.16,1500,890,36)

args=sys.argv[sys.argv.index('--')+1:]
if 'export' in args:
    for factory in products():
        init()
        save(factory())
if 'windows' in args:
    for sty in ('colonial','droit'):
        for w,height in WINDOWS:
            init()
            save(window(w,height,sty))
if 'stair' in args:
    init()
    save(staircase())
if 'maison' in args: scene_house()
if 'fenetre' in args: scene_house(True)
