from pathlib import Path
import math
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

root=Path(__file__).parent/'maps'
rng=np.random.default_rng(31415)
N=512
y,x=np.mgrid[:N,:N]/N
def noise(w):
    a=gaussian_filter(rng.normal(size=(N,N)),w,mode='wrap')
    return a/a.std()
def write(name,a,quality=94):
    Image.fromarray(np.clip(np.round(a*255),0,255).astype('uint8')).save(root/(name+'.jpg'),quality=quality,subsampling=0)
fine=noise(.9); mid=noise(3.8)
roller=noise((1.1,2.8)); spots=np.maximum(0,fine-1.02)
height=.26*fine+.35*roller+.18*mid-.45*spots
dx=(np.roll(height,1,1)-np.roll(height,-1,1))*.37
dy=(np.roll(height,-1,0)-np.roll(height,1,0))*.37
z=np.ones_like(dx)
write('gypse_normal',np.stack((dx,dy,z),axis=-1)/np.sqrt(dx*dx+dy*dy+1)[...,None]*.5+.5)
write('gypse_brut',(.87+.035*mid+.029*fine-.045*spots)[...,None]*np.array([1,.97,.895]))

# Original illustration in the photo frame.
n=720
canvas=Image.new('RGB',(n,540))
draw=ImageDraw.Draw(canvas)
for j in range(340):
    t=j/340
    draw.line((0,j,n,j),fill=tuple(round(a+(b-a)*t) for a,b in zip((55,95,119),(232,196,153))))
for layer,color in enumerate(((94,121,122),(60,95,99),(43,74,76),(31,55,51))):
    coords=[]
    for i in range(0,n+1,9):
        coords.append((i,270+40*layer+math.sin(i*.008+layer*1.7)*38+math.sin(i*.031+layer)*11+int(rng.integers(-9,10))))
    draw.polygon(coords+[(n,540),(0,540)],fill=color)
for i in range(68):
    px=int(rng.integers(0,n));py=int(rng.integers(443,575));h=int(rng.integers(35,155))
    w=h*.16
    draw.line((px,py,px,py-h),fill=(37,42,35),width=2)
    for j in range(5):
        peak=py-h+j*h*.12
        span=w*(.46+j*.14)
        draw.polygon([(px,peak),(px-span,peak+h*.35),(px+span,peak+h*.35)],fill=(32,55,47))
img=np.asarray(canvas).astype(float)/255
img+=rng.normal(0,.008,size=img.shape[:2])[...,None]
write('photo',img)
