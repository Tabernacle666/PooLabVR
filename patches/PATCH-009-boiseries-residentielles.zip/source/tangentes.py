from pathlib import Path
import json
import numpy as np

root=Path(__file__).with_name('kit')
repaired=0
for p in sorted(root.glob('*.gltf')):
    doc=json.loads(p.read_text())
    file=root/doc['buffers'][0]['uri']
    data=bytearray(file.read_bytes())
    def get(i):
        a=doc['accessors'][i]
        v=doc['bufferViews'][a['bufferView']]
        dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
        width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        return np.ndarray((a['count'],width),dtype,buffer=data,offset=v.get('byteOffset',0)+a.get('byteOffset',0),
                          strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize))
    cache=set()
    for mesh in doc['meshes']:
        for primitive in mesh['primitives']:
            attr=primitive['attributes']
            if 'TANGENT' not in attr or attr['TANGENT'] in cache:
                continue
            cache.add(attr['TANGENT'])
            position,normal,uv,tangent=map(get,(attr['POSITION'],attr['NORMAL'],attr['TEXCOORD_0'],attr['TANGENT']))
            invalid=np.flatnonzero(np.linalg.norm(tangent[:,:3],axis=1)<.5)
            if not len(invalid):continue
            triangles=get(primitive['indices']).reshape(-1,3)
            xyz=position[triangles].astype('float64')
            st=uv[triangles].astype('float64')
            delta1,delta2=xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]
            tex1,tex2=st[:,1]-st[:,0],st[:,2]-st[:,0]
            det=tex1[:,0]*tex2[:,1]-tex1[:,1]*tex2[:,0]
            for i in invalid:
                faces=np.flatnonzero(np.any(triangles==i,axis=1))
                k=faces[np.argmax(np.abs(det[faces]))]
                nn=normal[i].astype('float64')
                hand=1
                if abs(det[k])>1e-14:
                    u=(tex2[k,1]*delta1[k]-tex1[k,1]*delta2[k])/det[k]
                    v=(-tex2[k,0]*delta1[k]+tex1[k,0]*delta2[k])/det[k]
                    u-=nn*np.dot(nn,u)
                    if np.linalg.norm(u)>=1e-12:
                        hand=1 if np.dot(np.cross(nn,u),v)>=0 else -1
                else:
                    u=np.zeros(3)
                if np.linalg.norm(u)<1e-12:
                    axis=np.eye(3)[np.argmin(np.abs(nn))]
                    u=np.cross(nn,axis)
                tangent[i,:3]=u/np.linalg.norm(u)
                tangent[i,3]=hand
                repaired+=1
    file.write_bytes(data)
print('Tangentes locales corrigées',repaired)
