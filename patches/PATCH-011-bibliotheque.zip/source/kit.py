from pathlib import Path
from math import cos, exp, pi, sin, tau
from mathutils import Matrix, Vector
import bpy
import bmesh
import json
import sys

DIR = Path(__file__).resolve().parent
sys.path.insert(0,str(DIR))
import helpers as H

H.MAPS = DIR/'maps'
BOOKS = json.loads((DIR/'titres.json').read_text())
ATLAS = json.loads((DIR/'atlas.json').read_text())
BOOK_WIDTH = 1.080
BOOK_DEPTH = .348
BOOK_HEIGHT = 2.126
SHELVES = (.220, .550, .880, 1.210, 1.540)
Z = Vector((0,0,1))
X = Vector((1,0,0))
Y = Vector((0,1,0))
MATS = {}
LUX = .55

def material(key, name, color, rough, metal=0, maps=None, tint=None):
    m = H.material(name,color,rough,metal,maps=maps)
    MATS[key]=m
    if tint:
        nodes=m.node_tree.nodes
        links=m.node_tree.links
        shader=nodes.get('Principled BSDF')
        inp=shader.inputs['Base Color']
        source=inp.links[0].from_socket
        mix=nodes.new('ShaderNodeMixRGB')
        mix.blend_type='MULTIPLY'
        mix.inputs[0].default_value=1
        mix.inputs[2].default_value=(*tint,1)
        links.new(source,mix.inputs[1]);links.new(mix.outputs['Color'],inp)
    return m

def add_map(mat,file,target,strength=None):
    tree=mat.node_tree
    shader=tree.nodes.get('Principled BSDF')
    node=tree.nodes.new('ShaderNodeTexImage')
    node.image=bpy.data.images.load(str(H.MAPS/file),check_existing=True)
    if target in ('Normal','Roughness','Metallic'):
        node.image.colorspace_settings.name='Non-Color'
    s=node.outputs[0]
    if target=='Normal':
        normal=tree.nodes.new('ShaderNodeNormalMap')
        normal.inputs['Strength'].default_value=strength
        tree.links.new(s,normal.inputs['Color'])
        s=normal.outputs[0]
    tree.links.new(s,shader.inputs[target])
    return node

def setup():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATS.clear()
    wood=('wood_base.jpg','wood_rough.jpg','wood_normal.jpg')
    material('walnut','noyer_teinte_fibres',(.224,.113,.062),.43,maps=wood,tint=(.74,.66,.62))
    material('edge','noyer_arêtes_polies',(.31,.158,.076),.33,maps=wood,tint=(.91,.81,.68))
    material('panel','noyer_dos_quartier',(.18,.087,.044),.56,maps=wood,tint=(.55,.49,.46))
    material('brass','laiton_oxyde',(.42,.253,.084),.47,.71)
    material('linen','toile_charniere',(.157,.113,.079),.89)
    material('glue','colle_ancienne',(.247,.129,.053),.73)
    material('stitch','tranchefile_ecrue',(.556,.376,.181),.81)
    material('dyed','tranchefile_brique',(.277,.084,.036),.83)
    paper=material('paper','papier_tranches_fibres',(.59,.458,.30),.84)
    add_map(paper,'tranche.jpg','Base Color')
    add_map(paper,'tranche_normal.jpg','Normal',.60)
    for key,file in (('pageL','fables_ouvert_gauche.jpg'),('pageR','fables_ouvert_droite.jpg')):
        m=material(key,'papier_imprime_'+key,(.73,.61,.43),.85)
        add_map(m,file,'Base Color')
    joint=material('print','cuir_dore_ancien',(.21,.071,.045),.60)
    add_map(joint,'reliures.jpg','Base Color')
    add_map(joint,'reliures_normal.jpg','Normal',.66)
    nodes=joint.node_tree.nodes
    links=joint.node_tree.links
    rm=nodes.new('ShaderNodeTexImage')
    rm.image=bpy.data.images.load(str(H.MAPS/'reliures_rm.png'),check_existing=True)
    rm.image.colorspace_settings.name='Non-Color'
    channels=nodes.new("ShaderNodeSeparateColor")
    links.new(rm.outputs[0],channels.inputs[0])
    shader=nodes.get('Principled BSDF')
    links.new(channels.outputs['Green'],shader.inputs['Roughness'])
    links.new(channels.outputs['Blue'],shader.inputs['Metallic'])
    for m in MATS.values():
        m.use_backface_culling=True

def props(o,**data):
    for k,v in data.items():
        o[k]=v
    return o

def mount(o,p):
    o.parent=p
    return o

def socket(name,parent,pos,**data):
    return mount(H.empty(name,pos,role='socket',**data),parent)

def plane_uv(v,normal,grain=None):
    axis=max(range(3),key=lambda i:abs(normal[i]))
    others=[i for i in range(3) if i!=axis]
    if grain in others:
        others.remove(grain)
        others.append(grain)
    return tuple(v[j]/LUX for j in others)

def table_box(name,loc,dims,owner,mat='walnut',edge=.003,grain=2,phase=(0.,0.),**data):
    b=H.Part(name,pivot=loc,material_profile=data.pop('material_profile','wood'),**data)
    u=[-dims[0]/2,dims[0]/2]
    v=[-dims[1]/2,dims[1]/2]
    w=[-dims[2]/2,dims[2]/2]
    corners=[(x,y,z) for z in w for y in v for x in u]
    ids=[b.point(Vector(loc)+Vector(p)) for p in corners]
    for row,n in [((0,2,3,1),(0,0,-1)),((4,5,7,6),(0,0,1)),
                  ((0,1,5,4),(0,-1,0)),((2,6,7,3),(0,1,0)),
                  ((0,4,6,2),(-1,0,0)),((1,3,7,5),(1,0,0))]:
        uv=[tuple(q[j]+phase[j] for j in (0,1)) for q in (plane_uv(corners[i],n,grain) for i in row)]
        b.face([ids[i] for i in row],uv,MATS[mat],False)
    # Keep the six side faces as quads until the bevel can build correct corners.
    me=bpy.data.meshes.new(name)
    me.from_pydata(b.v,[],b.faces)
    me.update()
    me.materials.append(MATS[mat])
    o=bpy.data.objects.new(name,me)
    bpy.context.collection.objects.link(o)
    o.location=loc
    uv=me.uv_layers.new(name='UV')
    for face,q in zip(me.polygons,b.uvs):
        for l,coord in zip(face.loop_indices,q):
            uv.data[l].uv=coord
    if edge:
        bpy.context.view_layer.objects.active=o
        m=o.modifiers.new('Arrondi du bois','BEVEL')
        m.width=edge;m.segments=3
        bpy.ops.object.modifier_apply(modifier=m.name)
        bpy.context.view_layer.objects.active=o
        m=o.modifiers.new('Normales des faces principales','WEIGHTED_NORMAL')
        m.keep_sharp=True
        bpy.ops.object.modifier_apply(modifier=m.name)
    return mount(props(o,**b.props),owner)

def finish(p,owner,repair=False):
    obj=p.finish()
    if repair:
        bm=bmesh.new()
        bm.from_mesh(obj.data)
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
        bm.to_mesh(obj.data);bm.free()
        obj.data.update()
    return mount(obj,owner)

def carcass_profile(name,rows,p,mat):
    # One continuous crown/plinth section with mitered corners.
    m=H.Part(name,material_profile='wood')
    rings=[]
    for z,w,y0,y1 in rows:
        rings.append([m.point(pos) for pos in ((-w/2,y0,z),(w/2,y0,z),(w/2,y1,z),(-w/2,y1,z))])
    for j,(a,b) in enumerate(zip(rings,rings[1:])):
        for i in range(4):
            k=(i+1)%4
            n=(Vector(m.v[a[k]])-Vector(m.v[a[i]])).cross(Vector(m.v[b[i]])-Vector(m.v[a[i]])).normalized()
            row=(a[i],a[k],b[k],b[i])
            m.face(row,[plane_uv(m.v[k],n,0 if i%2==0 else 1) for k in row],MATS[mat],False)
    for row in (rings[0][::-1],rings[-1]):
        m.face(row,[plane_uv(m.v[i],Z,0) for i in row],MATS[mat],False)
    return finish(m,p)

def routed_panel(side,root):
    # Raised side panel inside a continuous stepped moulding. Each strip has its own grain direction.
    k=H.Part('panneau_latéral_'+side,material_profile='wood')
    sign=-1 if side=='G' else 1
    loops=[]
    outline=((.050,.223),(.295,.223),(.295,1.954),(.050,1.954))
    mid=(.1725,1.0885)
    for progress,swell in ((0.,0.),(.02,.0049),(.047,.0081),(.077,.0090),(.100,.0078),(.134,.0028),
                           (.168,-.0015),(.204,-.0021),(.245,.0018),(.287,.0042),(.320,.0047)):
        loops.append([k.point((sign*(.511+swell),y+progress*(mid[0]-y),z+progress*.23*(mid[1]-z))) for y,z in outline])
    for j,(a,b) in enumerate(zip(loops,loops[1:])):
        for i in range(4):
            l=(i+1)%4
            inds=(a[i],a[l],b[l],b[i])
            k.face(inds,[(k.v[n][1]/LUX,k.v[n][2]/LUX) for n in inds],MATS['edge' if j in (2,3,8) else 'walnut'],False)
    k.face(loops[-1],[(k.v[n][1]/LUX,k.v[n][2]/LUX) for n in loops[-1]],MATS['walnut'],False)
    back=[k.point((sign*.505,k.v[i][1],k.v[i][2])) for i in loops[0]]
    for i in range(4):
        j=(i+1)%4
        inds=(back[i],back[j],loops[0][j],loops[0][i])
        k.face(inds,[(k.v[n][1]/LUX+k.v[n][0],k.v[n][2]/LUX+k.v[n][0]*.45) for n in inds],MATS['walnut'],False)
    k.face(back,[(k.v[n][1]/LUX,k.v[n][2]/LUX) for n in back],MATS['walnut'],False)
    return finish(k,root,repair=True)

def arch_fascia(p):
    p2=H.Part('traverse_archée',material_profile='wood')
    n=43
    stacks=[]
    for depth,z_shift in ((.011,0.),(.015,-.003),(.022,-.002),(.049,0.)):
        line=[]
        for i in range(n):
            u=-1+2*i/(n-1)
            z=1.859+.112*max(0.,cos(pi*u/2))**1.14
            line.append(p2.point((u*.476,depth,z+z_shift)))
        stacks.append(line)
    up=[p2.point((- .476,.015,2.057)),p2.point((.476,.015,2.057))]
    rear=[p2.point((- .476,.049,2.057)),p2.point((.476,.049,2.057))]
    def face(inds,material='walnut'):
        pp=[p2.v[i] for i in inds]
        cs=[((x+y*.61)/LUX,(z+y*.88)/LUX) for x,y,z in pp]
        p2.face(inds,cs,MATS[material],False)
    face(stacks[0]+up[::-1])
    face(stacks[-1]+rear[::-1])
    for j,(a,b) in enumerate(zip(stacks,stacks[1:])):
        for i in range(n-1):
            face([a[i],b[i],b[i+1],a[i+1]],'edge' if j==1 else 'walnut')
    face([up[0],up[1],rear[1],rear[0]])
    for i,top in ((0,0),(n-1,1)):
        face([row[i] for row in stacks]+[rear[top],up[top]])
    finish(p2,p,True)

def medallion(p):
    # A small, carved eight-lobed flower in front of the lintel.
    k=H.Part('rosace_fraisée',material_profile='wood')
    radius=.030
    rows=[(.006,1.0),(.001,.98),(-.001,.86),(-.0017,.72),(.000,.53),(-.0037,.32),(-.0047,.15)]
    n=64
    rings=[]
    for yy,s in rows:
        rings.append([k.point((r*cos(a),yy,2.014+r*sin(a))) for j in range(n)
                      for a in [tau*j/n] for r in [radius*s*(.87+.13*cos(8*a))]])
    for j,(a,b) in enumerate(zip(rings,rings[1:])):
        for i in range(n):
            s=(i+1)%n
            inds=(a[i],a[s],b[s],b[i])
            k.face(inds,[(k.v[i][0]/LUX+k.v[i][1]*.49,k.v[i][2]/LUX+k.v[i][1]) for i in inds],
                   MATS['edge' if j==4 else 'walnut'],True)
    for row in (rings[0],rings[-1]):
        k.face(row,[(k.v[n][0]/LUX,k.v[n][2]/LUX) for n in row],MATS['edge'],False)
    o=finish(k,p,True)
    o.location.y=.010

def cabinet(identifier='bibliotheque_vide'):
    p=H.empty(identifier,asset_id='oasis_bibliotheque_1080',component_id='corpus',
              width_m=BOOK_WIDTH,depth_m=BOOK_DEPTH,height_m=BOOK_HEIGHT,
              assembly='bibliotheque_livres',units='metres',role='cabinet')
    for i in range(5):
        # Independent back boards are visible in the deliberately empty bays.
        x=-.390+i*.195
        table_box(f'dos_{i:02d}',(x,.328,1.080),(.194,.016,1.840),p,'panel',edge=.0014,phase=(.043*i,.187*i))
    for sign,side in ((-1,'G'),(1,'D')):
        sx=sign*.501
        table_box('joue_'+side,(sx,.171,1.090),(.032,.301,1.901),p,edge=.004)
        table_box('montant_face_'+side,(sx,.020,1.082),(.063,.056,1.95),p,'walnut',edge=.004)
        table_box('montant_dos_'+side,(sx,.307,1.085),(.062,.061,1.91),p,'walnut',edge=.004)
        table_box('filet_face_'+side,(sx,-.010,1.085),(.019,.010,1.868),p,'edge',edge=.0035)
        routed_panel(side,p)
    for i,z in enumerate(SHELVES):
        s=H.empty(f'niveau_{i+1}',(0,0,z),role='shelf',level=i+1,max_book_height_m=.310)
        mount(s,p)
        table_box(f'tablette_{i+1}',(0,.171,-.013),(.961,.304,.026),s,'walnut',edge=.0033,grain=0,phase=(.01,.23*i))
        table_box('nez_moulure',(0,.013,-.017),(.960,.029,.030),s,'edge',edge=.006,grain=0,phase=(.04,.16*i))
        for x in (-.468,.468):
            for y in (.079,.278):
                # Round steel/bronze pins inside the cabinet only.
                pin=H.Part('taquet',material_profile='metal')
                H.collar(pin,(x,y,-.032),X*(1 if x<0 else -1),.013,.0048,MATS['brass'],14)
                finish(pin,s)
        socket(f'pose_tablette_{i+1}',s,(0,.013,0),zone='book_fit',width_m=.932,depth_m=.298)
    arch_fascia(p);medallion(p)
    carcass_profile('corniche_ogee',[(2.028,1.029,.001,.329),(2.041,1.029,-.002,.331),
                    (2.045,1.039,-.007,.335),(2.053,1.050,-.012,.337),(2.062,1.053,-.015,.340),
                    (2.075,1.060,-.018,.341),(2.082,1.072,-.019,.341),(2.087,1.080,-.023,.342),
                    (2.100,1.080,-.024,.342),(2.107,1.076,-.023,.341),(2.122,1.078,-.022,.341),
                    (2.126,1.071,-.020,.340)],p,'walnut')
    carcass_profile('socle_mouluré',[(.046,1.063,-.024,.337),(.061,1.080,-.024,.342),
                    (.122,1.080,-.024,.342),(.130,1.073,-.021,.340),(.134,1.057,-.019,.337),
                    (.141,1.051,-.016,.336),(.150,1.051,-.015,.334),(.162,1.039,-.009,.331),
                    (.174,1.027,-.001,.326)],p,'edge')
    for i,x in enumerate((-.456,.456)):
        for j,y in enumerate((.026,.294)):
            foot=H.Part(f'pied_{i}_{j}',material_profile='wood')
            H.profile(foot,(x,y,0.),Z,[(0,0),(0,.027),(.003,.033),(.009,.039),(.023,.041),(.038,.033),
                      (.048,.027),(.063,.026),(.075,.036),(.080,.036),(.080,0)],
                      MATS['walnut'],32,period=.4)
            finish(foot,p)
    socket('alignement_gauche',p,(-.54,0,0),role_in_asset='module_seam')
    socket('alignement_droit',p,(.54,0,0),role_in_asset='module_seam')
    return p

def atlas(i,region,u,v):
    x,y,w,h=ATLAS['papier'] if region=='paper' else ATLAS['faces'][i][region]
    pw,ph=ATLAS['size']
    eps=2.5
    return ((x+eps+(w-2*eps)*u)/pw,1-(y+eps+(h-2*eps)*(1-v))/ph)

def flat_uvs(p,inds,i,region,bounds,reverse=False):
    y0,z0,depth,height=bounds
    vertices=[p.v[n] for n in inds]
    return [atlas(i,region,(1. if reverse else 0.)+(-1 if reverse else 1)*(y-y0)/depth,(z-z0)/height)
            for _,y,z in vertices]

def plate(i,owner,front_side,t,h,d):
    # Outer cuts and corners are deliberately irregular under sharp lighting.
    sign=-1 if front_side else 1
    name='plat_avant' if front_side else 'plat_arriere'
    reg='front' if front_side else 'back'
    board=H.Part(name,role='book_board',material_profile='leather',component_id=name)
    y0=.0049
    def round_outline(inset,z0,z1):
        corners=[(y0+inset,z0),(d-inset,z0),(d-inset,z1),(y0+inset,z1)]
        radii=[.0049,.0060+(i%3)*.00042,.0051+((i+1)%3)*.00036,.0040]
        out=[]
        for j,((y,z),r) in enumerate(zip(corners,radii)):
            # Points progress counterclockwise within the plane.
            u=(1 if j in (0,3) else -1)
            v=(1 if j<2 else -1)
            r=max(.0018,r-inset)
            cy,cz=y+u*r,z+v*r
            for a in range(7):
                q=pi*(1+j*.5)+a*pi/12
                xx=cy+r*cos(q);zz=cz+r*sin(q)
                if j in (1,2):
                    zz+=.00031*sin(a*1.9+i*.73)*sin(a*pi/6)
                out.append((xx,zz))
        return out
    loops=[]
    for x,inset,z0,z1 in ((t/2-.0038,.0004,.0004,h-.0005),(t/2-.002,.0000,.0,h),
                           (t/2-.00041,.00023,.0003,h-.0003),(t/2,.0011,.0011,h-.0012)):
        loops.append([board.point((sign*x,y,z)) for y,z in round_outline(inset,z0,z1)])
    def u(row):
        return flat_uvs(board,row,i,reg,(y0,0.,d-y0,h),front_side)
    n=len(loops[0])
    for a,b in zip(loops,loops[1:]):
        for k in range(n):
            l=(k+1)%n
            row=[a[k],a[l],b[l],b[k]]
            # Wrap the coloured leather over the board edge.
            board.face(row,u(row),MATS['print'],True)
    board.face(loops[-1],u(loops[-1]),MATS['print'],False)
    inside=loops[0][::-1]
    board.face(inside,[(board.v[n][1]/.21,board.v[n][2]/.24) for n in inside],MATS['linen'],False)
    finish(board,owner,True)

def book_spine(i,owner,t,h):
    p=H.Part('dos_arrondi_nerfs',material_profile='leather',role='spine',component_id='dos')
    stations={0.,.006,.014,.027,.970,.986,.994,1.}
    bands=(.071,.182,.390,.675,.852,.926)
    for z in bands:
        stations.update(z+k for k in (-.015,-.012,-.007,0,.007,.012,.015))
    stations=sorted(stations)
    n=18
    front=[];back=[]
    for j,a in enumerate(stations):
        amp=sum(exp(-((a-z)/.0084)**2) for z in bands)
        f=sin(pi*a)**.8
        for k in range(n+1):
            u=k/n
            swell=sin(pi*u)**.76
            pull=(1.0-.31*cos(2*pi*a+1.7*i))*0.00020
            x=(u-.5)*(t-.0007)+(.00025*sin(a*4.2+1.8*i)*f)
            y=.0032-.0104*swell-.00134*amp*(.37+.63*swell)+pull*sin(5*pi*u)
            z=h*a+(.00026*sin(i+5.1*u)*cos(2*pi*a)*f)
            front.append(p.point((x,y,z)))
            back.append(p.point((x,.019,z)))
    for j in range(len(stations)-1):
        for u in range(n):
            l=j*(n+1)+u
            row=(l,l+1,l+n+2,l+n+1)
            uv=[atlas(i,'spine',(r%(n+1))/n,stations[r//(n+1)]) for r in row]
            p.face([front[k] for k in row],uv,MATS['print'],True)
            p.face([back[k] for k in row[::-1]],uv[::-1],MATS['linen'],False)
    corners=(list(range(n+1)) + [k*(n+1)+n for k in range(1,len(stations))] +
             list(range(len(front)-2,len(front)-n-2,-1)) + [k*(n+1) for k in range(len(stations)-2,0,-1)])
    for a,b in zip(corners,corners[1:]+corners[:1]):
        row=(front[a],back[a],back[b],front[b])
        if a%(n+1)==b%(n+1):
            side=a%(n+1)==0
            uv=[atlas(i,'spine',(0.018 if side else .982)+(1. if side else -1.)*(p.v[k][1]-.003)*6.,p.v[k][2]/h)
                for k in row]
        else:
            at_bottom=a//(n+1)==0
            uv=[atlas(i,'spine',.5+p.v[k][0]/t,(.011 if at_bottom else .989)+(1. if at_bottom else -1.)*(p.v[k][1]+.010)*2.)
                for k in row]
        p.face(row,uv,MATS['print'],False)
    finish(p,owner,True)

def paper_block(i,owner,t,h,d):
    # The closing edge carries a curved surface, with small signature ridges rather than stacked cards.
    p=H.Part('bloc_feuillets',material_profile='paper',role='page_block')
    g=33
    rings=[[] for _ in range(4)]
    for k in range(g+1):
        u=k/g
        x=(u-.5)*(t-.0062)
        y1=d-.0054+.0017*cos((u-.5)*pi)+.00040*sin(8*pi*u+i)
        z0=.0029+.00023*sin(k*2.29+i)
        z1=h-.0035+.00027*cos(k*2.83)
        for rind,pos in zip(rings,((x,.015,z0),(x,y1,z0),(x,y1,z1),(x,.015,z1))):
            rind.append(p.point(pos))
    for j in range(4):
        a,b=rings[j],rings[(j+1)%4]
        for k in range(g):
            row=(a[k],a[k+1],b[k+1],b[k])
            # U follows the page edge, V crosses the thickness and the fine leaf lines.
            uv=[(0,k/g*1.4),(0,(k+1)/g*1.4),(1,(k+1)/g*1.4),(1,k/g*1.4)]
            p.face(row,uv,MATS['paper' if j in (0,1,2) else 'glue'],j in (0,1,2))
    for k in (0,g):
        row=[r[k] for r in rings]
        p.face(row,[(p.v[n][1],p.v[n][2]) for n in row],MATS['paper'],False)
    finish(p,owner,True)

def headband(i,owner,t,h):
    # True small alternating ribs at both ends of the rounded spine.
    p=H.Part('tranchefiles_alternees',material_profile='cloth',role='headbands')
    n=23
    for z,s in ((.0030,1),(h-.0040,-1)):
        for k in range(n):
            u=(k+.5)/n
            x=(u-.5)*(t-.007)
            y=.0109-.0042*sin(pi*u)
            mat=MATS['stitch' if (k+i)%3 else 'dyed']
            c=(x,y,z)
            H.profile(p,c,Z*s,[(0,0),(0,.00049),(.00053,.00058),(.00108,.00033),(.00120,0)],
                      mat,8,period=.02)
    finish(p,owner,True)

def book(i,identifier=None):
    b=BOOKS[i]
    t,h,d=b['dimensions_m']
    p=H.empty(identifier or f'livre_{b["id"]}',book_id=b['id'],component_id=b['id'],
              role='pickable_book',title=b['titre'],primary_action='prendre_reposer',reading='notice_dos',
              width_m=t,height_m=h,depth_m=d,mass_kg=round(t*h*d*594,2))
    plate(i,p,True,t,h,d)
    plate(i,p,False,t,h,d)
    book_spine(i,p,t,h)
    paper_block(i,p,t,h,d)
    headband(i,p,t,h)
    socket('prise',(p),(0,.072,.118),role_in_asset='grip')
    socket('pose_livre',p,(0.,0.,0.),role_in_asset='placement')
    return p

# Coordinates are metre offsets from the centre of each shelf.
RUNS=(
    (1,'gauche',-.419,(5,1,2,0),.014),
    (1,'droite', .166,(3,4,2,1),.008),
    (2,'gauche',-.334,(0,5,4,3,3),.011),
    (4,'centre',-.104,(2,1,0,5),.012),
    (5,'gauche',-.376,(4,2,3),.014),
    (5,'droite', .195,(0,1,5),.009),
)

def layout():
    runs=[]
    natural_z=(.0017,.0021,.0015,.0024,.0019,.0018)
    for number,(level,tag,left,books,gap) in enumerate(RUNS):
        seq=[]
        for j,i in enumerate(books):
            t,h,d=BOOKS[i]['dimensions_m']
            lean=(.014 if number%2 else .021) if j==len(books)-1 else 0.
            yaw=.034*sin(j*3.4+number*.88)
            depth=.037+.007*(1+cos(j*2.11+number))
            xx=left+t*.5
            seq.append({'slot':f'{level}_{tag}_{j+1:02d}','book':BOOKS[i]['id'],'index':i,
                        'position_blender':[xx,depth,SHELVES[level-1]+natural_z[j]],
                        'yaw':yaw,'lean':lean})
            left+=t+gap
        runs.append({'level':level,'id':f'rangee_{level}_{tag}','books':seq})
    return runs

def transform_for(pos):
    return Matrix.Translation(Vector(pos['position_blender'])) @ Matrix.Rotation(pos['lean'],4,'Y') @ Matrix.Rotation(pos['yaw'],4,'Z')

def proxy(run,owner):
    # Each run is a single mesh/material. Books keep their top silhouette, colour,
    # depth and narrow inter-book gaps. Voids between runs remain empty.
    seq=run['books']
    origin=Vector((seq[0]['position_blender'][0],0,SHELVES[run['level']-1]))
    p=H.Part(run['id'],pivot=origin,role='mg2_group_source',level=run['level'],
             component_id=run['id'],material_profile='mixed_leather_paper',
             covers_slots=' '.join(a['slot'] for a in seq))
    for pos in seq:
        i=pos['index']
        t,h,d=BOOKS[i]['dimensions_m']
        vs=[(-t/2,-.005,0),(t/2,-.005,0),(-t/2,d,0),(t/2,d,0),
            (-t/2,-.005,h),(t/2,-.005,h),(-t/2,d,h),(t/2,d,h)]
        transformed=transform_for(pos)
        inds=[p.point(transformed@Vector(v)) for v in vs]
        for row,region in [((0,1,5,4),'spine'),((2,6,7,3),'paper'),
                           ((4,5,7,6),'paper'),((0,2,3,1),'paper'),
                           ((0,4,6,2),'front'),((1,3,7,5),'back')]:
            uv=[]
            for k in row:
                x,y,z=vs[k]
                if region=='spine':u,v=.5+x/t,z/h
                elif region=='front':u,v=1-(y+.005)/(d+.005),z/h
                elif region=='back':u,v=(y+.005)/(d+.005),z/h
                else:u,v=(y+.005)/(d+.005)*.91+z/h*.09,.5+x/t
                uv.append(atlas(i,region,u,v))
            p.face([inds[k] for k in row],uv,MATS['print'],False)
    return finish(p,owner)

def stock(mode):
    p=cabinet('bibliotheque_clairsemee' if mode=='detail' else 'bibliotheque_clairsemee_agregee')
    props(p,layout_id='claire01',representation=mode)
    if mode=='detail':
        prototypes={}
        for i in sorted({q['index'] for r in layout() for q in r['books']}):
            prototypes[i]=book(i)
        for r in layout():
            for record in r['books']:
                proto=prototypes[record['index']]
                item=proto.copy()
                bpy.context.collection.objects.link(item)
                item.name=f'livre_{record["slot"]}'
                item['component_id']=record['slot']
                item['slot_id']=record['slot']
                item['parent_group']=r['id']
                item.parent=p
                item.matrix_local=transform_for(record)
                for obj in proto.children:
                    duplicate=obj.copy()
                    bpy.context.collection.objects.link(duplicate)
                    duplicate.parent=item
                    duplicate.matrix_local=obj.matrix_local
                s=socket(f'pose_{record["slot"]}',p,record['position_blender'],slot_id=record['slot'],parent_group=r['id'])
                s.matrix_local=transform_for(record)
        for proto in prototypes.values():
            for obj in list(proto.children):
                bpy.data.objects.remove(obj,do_unlink=True)
            bpy.data.objects.remove(proto,do_unlink=True)
    else:
        for r in layout():
            proxy(r,p)
    return p

def open_book():
    b=BOOKS[0]
    t,h,d=b['dimensions_m']
    p=H.empty('livre_lafontaine_i_ouvert',role='book_reading_pose',book_id=b['id'],
              title=b['titre'],primary_action='lire',display_pose='ouverte')
    for sign,tag in ((-1,'gauche'),(1,'droite')):
        cover=H.Part('couverture_'+tag,material_profile='leather')
        coordinates=[]
        edge_y=.010
        edge_d=.004
        gaps=((.009,-edge_y),(.015,-.013),(d-.007,-.012),(d-.001,-.008),(d+.001,-.002),
              (d+.001,h-.004),(d-.003,h+.004),(d-.008,h+.007),(.017,h+.007),(.009,h+.003))
        for z in (.004,.009):
            coordinates.append([cover.point((sign*x,y,z+.003*sin(pi*x/d))) for x,y in gaps])
        def draw(inds,r):
            uv=[atlas(0,r,abs(cover.v[i][0])/d,cover.v[i][1]/h) for i in inds]
            cover.face(inds,uv,MATS['print'],False)
        outside,inside=coordinates
        draw(outside,'front')
        draw(inside,'back')
        for j in range(len(outside)):
            k=(j+1)%len(outside)
            draw([outside[j],outside[k],inside[k],inside[j]],'front')
        finish(cover,p,True)
        pages=H.Part('cahier_'+tag,role='bound_pages',material_profile='paper')
        xcount,ycount=37,21
        top=[];base=[]
        for i in range(xcount+1):
            u=i/xcount
            z=.021+.023*exp(-u*10.)+.013*sin(pi*u)-.002*cos(u*12.+sign)
            xx=sign*(.0009+(d-.0071)*u)
            for j in range(ycount+1):
                v=j/ycount
                l=.0035+v*(h-.0074)+.00062*sin(5.6*pi*u+.85*sign)*sin(pi*v)
                ripple=.00160*cos(u*18.+sign)*sin(v*pi*2)**2
                top.append(pages.point((xx,l,z+ripple)))
                base.append(pages.point((xx,l,.0093+u*.0006)))
        material=MATS['pageL' if sign<0 else 'pageR']
        for i in range(xcount):
            for j in range(ycount):
                q=i*(ycount+1)+j
                ids=(q,q+ycount+1,q+ycount+2,q+1)
                uv=[((1-k//(ycount+1)/xcount) if sign<0 else k//(ycount+1)/xcount,
                      (k%(ycount+1))/ycount) for k in ids]
                pages.face([top[k] for k in ids],uv,material,True)
        boundary=(list(range(ycount+1))+[u*(ycount+1)+ycount for u in range(1,xcount+1)]+
                  [xcount*(ycount+1)+v for v in range(ycount-1,-1,-1)]+[u*(ycount+1) for u in range(xcount-1,0,-1)])
        pages.face([base[k] for k in boundary],[(pages.v[base[k]][0]*8,pages.v[base[k]][1]*8) for k in boundary],MATS['paper'],False)
        for a,b in zip(boundary,boundary[1:]+boundary[:1]):
            h0=(Vector(pages.v[top[a]])-Vector(pages.v[base[a]])).length
            h1=(Vector(pages.v[top[b]])-Vector(pages.v[base[b]])).length
            u0=a/(xcount+ycount)*2;u1=b/(xcount+ycount)*2
            pages.face((base[a],base[b],top[b],top[a]),((u0,0),(u1,0),(u1,h1*32),(u0,h0*32)),MATS['paper'],True)
        finish(pages,p,True)
    # Leather ridge and the rounded gutter sit underneath the open signatures.
    table_box('reliure_du_dos',(0.,h*.5,.0065),(.027,h+.010,.012),p,'linen',edge=.0041,grain=1,material_profile='leather')
    socket('prise_garde',p,(0,.129,.013),role_in_asset='grip')
    return p

def export(p):
    path=DIR/'kit'
    path.mkdir(exist_ok=True)
    bpy.ops.export_scene.gltf(filepath=str(path/(p.name+'.gltf')),
                              export_format='GLTF_SEPARATE',export_texture_dir='textures',
                              export_yup=True,export_tangents=True,export_extras=True,
                              export_draco_mesh_compression_enable=False)

def gltf_position(obj):
    x,y,z=obj
    return [round(x,7),round(z,7),round(-y,7)]

def write_layout():
    groups=[]
    for r in layout():
        q=[]
        for b in r['books']:
            q.append({'slot':b['slot'],'book_id':b['book'],'position_m':gltf_position(b['position_blender']),
                      'mesh_node':f'livre_{b["slot"]}','placement_socket':f'pose_{b["slot"]}'})
        groups.append({'id':r['id'],'shelf':r['level'],'proxy_node':r['id'],'slots':q})
    scene={'id':'claire01','detail':'kit/bibliotheque_clairsemee.gltf',
           'groups':'kit/bibliotheque_clairsemee_agregee.gltf','empty':'kit/bibliotheque_vide.gltf',
           'module_width_m':BOOK_WIDTH,'shelf_levels_m':SHELVES,'rangees':groups}
    (DIR/'emplacements.json').write_text(json.dumps(scene,indent=2)+'\n')

def studios(scene_name,cam_pos,target,scale,w,h,samples=36,exposure=0.):
    s=bpy.context.scene
    s.world=bpy.data.worlds.new('Ciel diffuse')
    world=s.world;world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.46,.56,.65,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.29
    camera_data=bpy.data.cameras.new('camera')
    camera_data.type='ORTHO'
    camera_data.ortho_scale=scale
    cam=bpy.data.objects.new('camera',camera_data);s.collection.objects.link(cam);s.camera=cam
    cam.location=cam_pos
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    s.render.engine='CYCLES';s.cycles.samples=samples;s.cycles.use_denoising=False
    s.view_settings.view_transform='AgX'
    s.view_settings.exposure=exposure
    s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100
    s.render.image_settings.file_format='JPEG'
    s.render.image_settings.quality=94
    s.render.filepath=str(DIR/(scene_name+'.jpg'))
    bpy.ops.render.render(write_still=True)

def backdrop():
    root=H.empty('maison_apercu')
    material('plaster','gypse_olive_grisee',(.329,.365,.289),.87)
    material('floor','chene_du_sol',(.23,.15,.082),.68,maps=('wood_base.jpg','wood_rough.jpg','wood_normal.jpg'),
             tint=(.70,.69,.64))
    material('fabric','tapis_sombre',(.10,.085,.086),.91)
    table_box('mur',(0,1.10,1.49),(22,.07,4.0),root,'plaster',edge=0)
    for i in range(43):
        table_box('planche_sol',(0,-6+i*.305,-.030),(17,.303,.058),root,'floor',edge=.0015,grain=0,
                  phase=(.12*i,.044*i))
    table_box('plinthe_mur',(0,1.051,.063),(18,.035,.114),root,'panel',edge=.005,grain=0)
    H.add_light('fenetre',(-2.6,-3.6,4.66),825,(1.,.88,.73),3.6,(-.23,.12,.80))
    H.add_light('ciel',(3.2,-2.1,3.41),372,(.76,.86,1),4.60,(.02,.10,1.17))
    H.add_light('contrejour',(.37,.98,3.70),175,(1.,.73,.49),2.10,(-.15,.11,1.67))

def view_cabinets():
    setup()
    backdrop()
    a=cabinet('module_vide_aperçu');a.location=(-.550,.688,0)
    b=stock('detail');b.location=(.550,.688,0)
    studios('bibliotheque_rendu',(3.17,-7.72,3.38),(0,.751,1.059),3.16,1550,1190,35)

def horizontal(o,x,y,z,top='front',turn=0):
    angle=pi/2 if top=='front' else -pi/2
    o.matrix_world=Matrix.Translation(Vector((x,y,z))) @ Matrix.Rotation(angle+turn,4,'Z') @ Matrix.Rotation(angle,4,'Y')

def book_studio(style):
    setup()
    root=H.empty('atelier_de_reliure')
    material('felt','feutre_sombre',(.091,.111,.095),.94)
    table_box('plan_apercu',(0,0,-.038),(20,20,.074),root,'felt',edge=0)
    if style=='fermes':
        a=book(0)
        horizontal(a,-.024,-.116,.022,turn=-.082)
        b=book(0,'fables_notice_aperçu')
        horizontal(b,.025,-.123,.021,top='back',turn=.074)
        H.add_light('atelier_fenetre',(-.32,-.22,.64),10.2,(1.,.86,.68),.43,(-.13,.06,.025))
        H.add_light('atelier_remplissage',(.44,.25,.43),4.8,(.82,.90,1.),.57,(.10,.03,.038))
        H.add_light('atelier_rasant',(-.05,.33,.195),2.4,(1.,.89,.72),.21,(-.01,.04,.034))
        studios('livres_rendu',(.045,-.28,.75),(0,.004,.015),.420,1540,1140,38,-.36)
    else:
        a=open_book()
        a.location=(0,-.090,0.)
        a.rotation_euler.z=-.12
        H.add_light('atelier_fenetre',(-.46,-.42,.67),23,(1.,.87,.69),.60,(-.11,.04,.03))
        H.add_light('atelier_remplissage',(.37,.28,.42),8.3,(.79,.90,1.),.49,(.11,.05,.038))
        H.add_light('atelier_rasant',(.10,.34,.117),3,(1.,.88,.71),.18,(0,.04,.02))
        studios('fables_ouvert_rendu',(.105,-.225,.64),(0,.025,.011),.448,1320,950,34,-.20)

def row_test():
    # Render two identical shelf layouts side by side at a useful test distance.
    setup()
    backdrop()
    a=stock('detail');a.location=(-.554,.683,0)
    b=stock('proxy');b.location=(.554,.683,0)
    studios('rangees_comparaison',(.22,-4.9,1.84),(0,.729,1.549),2.31,1440,730,27)

def main():
    args=sys.argv[sys.argv.index('--')+1:]
    if 'export' in args:
        for i in range(len(BOOKS)):
            setup()
            export(book(i))
        for factory in (cabinet,lambda:stock('detail'),lambda:stock('proxy'),open_book):
            setup()
            export(factory())
        write_layout()
    if 'meubles' in args:view_cabinets()
    if 'cuirs' in args:book_studio('fermes')
    if 'ouvert' in args:book_studio('ouvert')
    if 'comparaison' in args:row_test()

if __name__=='__main__':
    main()
