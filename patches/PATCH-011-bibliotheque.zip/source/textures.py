from pathlib import Path
import json, math, os
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
MAPS = ROOT / 'maps'
MAPS.mkdir(exist_ok=True)
BOOKS = json.loads((ROOT / 'titres.json').read_text())
FONT = Path(os.environ.get('OASIS_SERIF_DIR', '/usr/share/fonts/opentype/urw-base35'))

def font(size, style='Roman'):
    p = FONT / f'P052-{style}.otf'
    if not p.exists():
        p = Path('/usr/share/fonts/truetype/dejavu') / ('DejaVuSerif-Bold.ttf' if style=='Bold' else 'DejaVuSerif.ttf')
    return ImageFont.truetype(str(p), max(9, round(size)))

W, H = 2304, 3072
CW, CH = W//2, 1008
FACES = {'back':(16,450), 'spine':(486,162), 'front':(674,462)}
FACE_TOP, FACE_HEIGHT = 24, 946
paper_slot = (28,3040,2248,22)
rng = np.random.default_rng(2711)

def uint(a):
    return np.clip(np.round(a),0,255).astype(np.uint8)

def noise(shape, sigma):
    x = rng.normal(size=shape).astype(np.float32)
    x = gaussian_filter(x, sigma, mode='wrap')
    return x / max(.000001, x.std())

def pigment(tile, palette):
    h,w=tile
    big = noise(tile, 56)
    medium = noise(tile, 15)
    pores = noise(tile,1.1)
    coarse = noise(tile,2.3)
    short = noise(tile,(1.1,3.6))
    fiber = noise(tile,(13,1.0))
    yy,xx = np.mgrid[:h,:w]
    dist = np.minimum.reduce([np.abs(xx - edge) for a,r in FACES.values() for edge in (a,a+r)] +
                             [np.abs(yy-FACE_TOP),np.abs(yy-(FACE_TOP+FACE_HEIGHT))]).astype(np.float32)
    rub = np.exp(-dist/8.)*np.clip(.6+.21*medium+.13*coarse, .16,1)
    # Irregular cracks in the finish. Pores and polished patches live at different scales.
    field = noise(tile,8.2)+.23*coarse
    creases = np.maximum(0, .11-np.abs(field-.46)) * np.clip(.31+.31*big+.35*medium,0,1.20)
    creases *= np.clip(.72+.19*coarse,0,1)
    orange_peel = .37*coarse+.26*short-.45*np.maximum(0,pores-.8)
    scratched = np.maximum(0,fiber-2.0)*.19
    base = np.asarray(palette,dtype='float32')[None,None,:]
    light = np.array([81,61,41],dtype='float32')[None,None,:]
    color = (base*(1.+(.073*big+.059*medium+.039*coarse+.021*pores)[...,None]) +
             light * rub[...,None])
    color=color + np.array([32,22,14])*(scratched[...,None]*.50) - creases[...,None]*np.array([52,40,31])
    rough = .58+.063*medium+.029*short-.105*rub+.034*big
    bump = .42*orange_peel-.83*creases+.16*scratched+.035*short
    return color, rough, bump, medium, coarse

def foil_layout(book):
    mask = Image.new('L',(CW,CH),0)
    d = ImageDraw.Draw(mask)
    def stroke(points,weight=3,ink=220):
        d.line([(round(x),round(y)) for x,y in points],fill=ink,width=weight,joint='curve')
    def loop(x,y,r,petals=None,weight=3,ink=224):
        c=[]
        for j in range(241):
            t=math.tau*j/240
            q=.75+.25*math.cos(petals*t) if petals else 1.
            c.append((x+q*r*math.cos(t),y+q*r*math.sin(t)))
        stroke(c,weight,ink)
    def center(text,left,right,y,size,style='Roman',ink=245):
        f=font(size,style)
        while f.getlength(text)>right-left:
            size-=1
            f=font(size,style)
        d.text(((left+right)/2,y),text,font=f,anchor='mt',fill=ink)
    def border(rect,scale=1):
        x,y,w,h=rect
        for s,t in [(24,4),(33,2),(40,1)]:
            d.rectangle((x+s,y+s,x+w-s,y+h-s),outline=211,width=t)
        for a in (0,1):
            for b in (0,1):
                cx=x+(w-37 if a else 37);cy=y+(h-37 if b else 37)
                sx=-1 if a else 1;sy=-1 if b else 1
                def pts(v):
                    return [(cx+sx*xx,cy+sy*yy) for xx,yy in v]
                stroke(pts([(0,29),(1,15),(10,5),(32,4),(61,11),(76,25),(69,39),(46,44),(25,38),
                            (17,26),(26,17),(42,18),(52,26),(42,33),(32,26)]),3,244)
                stroke(pts([(29,0),(15,1),(5,10),(4,32),(11,61),(25,76),(39,69),(44,46),(38,25),
                            (26,17),(17,26),(18,42),(26,52),(33,42),(26,32)]),3,244)
                stroke(pts([(16,16),(48,63),(63,48),(72,63),(62,79),(50,78),(48,63)]),3,220)
                loop(cx+sx*79,cy+sy*29,5)
                loop(cx+sx*29,cy+sy*79,5)
    def medallion(x,y,motif):
        loop(x,y,110,weight=4);loop(x,y,103,weight=2);loop(x,y,88,weight=2,ink=155)
        if motif=='renard':
            def p(v):
                return [(x+a,y+b) for a,b in v]
            stroke(p([(-67,-54),(-50,13),(0,63),(50,13),(67,-54),(32,-31),(0,-41),(-32,-31),(-67,-54)]),6,247)
            stroke(p([(-53,-37),(-39,5),(-19,17),(0,46),(19,17),(39,5),(53,-37)]),4)
            stroke(p([(-33,-2),(-17,8)]),5);stroke(p([(17,8),(33,-2)]),5)
            stroke(p([(-13,40),(0,55),(13,40)]),4)
            for yy in range(13,49,6):
                stroke(p([(-48+(yy-13)*.68,yy),(-38+(yy-13)*.80,yy+3)]),1,128)
                stroke(p([(48-(yy-13)*.68,yy),(38-(yy-13)*.80,yy+3)]),1,128)
        elif motif=='branche':
            stroke([(x-53,y+62),(x-28,y+22),(x-15,y+8),(x+4,y-11),(x+36,y-63)],6)
            for k in range(5):
                a=-41+k*17;b=45-k*23
                stroke([(x+a,y+b),(x+a-38,y+b-4),(x+a-42,y+b-19),(x+a-18,y+b-15),(x+a,y+b)],3)
                stroke([(x+a,y+b),(x+a+28,y+b-13),(x+a+40,y+b-7),(x+a+24,y+b+3),(x+a,y+b)],3)
        elif motif=='vagues':
            for k in range(-2,3):
                stroke([(x-63+i*2.1,y+19*k+8*math.sin(i*.2+.94*k)) for i in range(61)],4)
        elif motif=='rosace':
            loop(x,y,73,8,4);loop(x,y,51,8,3);loop(x,y,26,8);loop(x,y,9)
        else:
            n=8 if motif=='compas' else 5
            pts=[]
            for j in range(2*n+1):
                a=math.pi*j/n-math.pi/2
                r=(67 if (motif=='etoile' or j%4==0) else 54) if j%2==0 else 23
                pts.append((x+r*math.cos(a),y+r*math.sin(a)))
            stroke(pts,5,244)
            if motif=='compas':
                center('N',x-14,x+14,y-91,19,'Bold')
                center('S',x-14,x+14,y+75,18,'Bold')
            loop(x,y,14)
    x,w=FACES['front'];y=FACE_TOP;h=FACE_HEIGHT
    border((x,y,w,h))
    center(book['auteur'],x+52,x+w-52,y+178,34,'Italic')
    for row,word in enumerate(book['couverture']):
        center(word,x+45,x+w-45,y+255+row*81,81,'Bold')
    medallion(x+w/2,y+597,book['motif'])
    center('B I B L I O T H È Q U E',x+58,x+w-58,y+785,23)
    center('O A S I S',x+58,x+w-58,y+816,28,'Bold')
    center(book['marque'],x+70,x+w-70,y+881,25)
    x,w=FACES['back']
    border((x,y,w,h))
    center('Notice de lecture',x+51,x+w-51,y+188,47,'Bold')
    center('◇',x+70,x+w-70,y+250,34)
    d.line((x+122,y+301,x+w-122,y+301),fill=204,width=3)
    x1=x+62; width=w-124
    f=font(29)
    yy=y+354; line=''
    for word in book['notice'].split():
        next_text=(line+' '+word).strip()
        if line and f.getlength(next_text)>width:
            d.text((x1,yy),line,font=f,fill=247)
            yy+=42
            line=word
        else:
            line=next_text
    d.text((x1,yy),line,font=f,fill=247)
    center('ÉDITION OASIS',x+84,x+w-84,y+770,24)
    x,w=FACES['spine']
    d.rectangle((x+9,y+28,x+w-9,y+h-27),outline=176,width=2)
    for k in (.074,.189,.385,.665,.850,.932):
        st=y+round(h*k)
        d.line((x+12,st-10,x+w-12,st-10),fill=225,width=3)
        d.line((x+12,st+10,x+w-12,st+10),fill=197,width=3)
    center(book['dos_auteur'],x+13,x+w-13,y+241,29,'Bold')
    for k,line in enumerate(book['dos']):
        center(line,x+10,x+w-10,y+405+k*42,31,'Bold')
    loop(x+w/2,y+566,33);loop(x+w/2,y+566,25,5,4)
    center(book['marque'],x+25,x+w-25,y+692,42)
    return np.asarray(mask,dtype='float32')/255.

def atlas():
    color=np.zeros((H,W,3),dtype=np.uint8)
    normal=np.zeros((H//2,W//2,3),dtype=np.uint8)
    normal[:]=[128,128,255]
    arm=np.zeros_like(normal)
    arm[:]=[255,222,0]
    info=[]
    for i,book in enumerate(BOOKS):
        y=i//2*CH; x=i%2*CW
        rgb,rough,bump,big,small=pigment((CH,CW),book['cuir'])
        foil=foil_layout(book)
        frac=np.clip((.24+big*.17+small*.1),0.,.39)
        f=np.clip(foil*(1-frac*.64),0,1)
        worn=(np.clip(small*.13+big*.09,.0,.23))[...,None]
        gold=np.array([205,157,81])[None,None,:] - worn*np.array([100,75,24])
        rgb=rgb*(1-f[...,None])+gold*f[...,None]
        color[y:y+CH,x:x+CW]=uint(rgb)
        height=gaussian_filter(foil,.69)*.62 + bump
        xdiff=(np.roll(height,1,axis=1)-np.roll(height,-1,axis=1))*1.24
        ydiff=(np.roll(height,-1,axis=0)-np.roll(height,1,axis=0))*1.24
        xdiff=xdiff.reshape(CH//2,2,CW//2,2).mean(axis=(1,3))
        ydiff=ydiff.reshape(CH//2,2,CW//2,2).mean(axis=(1,3))
        nn=np.sqrt(1+xdiff**2+ydiff**2)
        normal[y//2:(y+CH)//2,x//2:(x+CW)//2]=uint(np.stack((xdiff/nn,ydiff/nn,1/nn),axis=-1)*127.5+127.5)
        rr=np.stack([np.full((CH,CW),255.),((1-f)*rough+f*.34)*255,np.clip(f*.87,0,1)*255],axis=-1)
        arm[y//2:(y+CH)//2,x//2:(x+CW)//2]=uint(rr.reshape(CH//2,2,CW//2,2,3).mean(axis=(1,3)))
        info.append({a:[x+left, y+FACE_TOP,width,FACE_HEIGHT] for a,(left,width) in FACES.items()})
    # A paper swatch in the common atlas travels with the row representations.
    px,py,pw,ph=paper_slot
    for r in range(ph):
        color[py+r,px:px+pw]=uint(np.array([193,172,131])*(.88+.14*math.cos(r*2.31)**2))
    Image.fromarray(color).save(MAPS/'reliures.jpg',quality=93,subsampling=0)
    Image.fromarray(normal).save(MAPS/'reliures_normal.jpg',quality=93,subsampling=0)
    Image.fromarray(arm).save(MAPS/'reliures_rm.png',compress_level=6)
    (ROOT/'atlas.json').write_text(json.dumps({'size':[W,H],'faces':info,'papier':paper_slot},indent=2)+'\n')
    h,w=512,512
    layer=np.random.default_rng(1982).normal(0,1,h).astype(np.float32)
    yy,xx=np.mgrid[:h,:w]
    height=(.20*np.cos(np.pi*2*yy/4.5 + .42*np.sin(xx*.025))+.086*layer[yy]+.053*noise((h,w),(.7,1.8)))
    color=np.array([192,165,124]) + (height*28+noise((h,w),11)*2.1)[...,None]
    nx=(np.roll(height,1,1)-np.roll(height,-1,1))*.61
    ny=(np.roll(height,-1,0)-np.roll(height,1,0))*.61
    norm=np.sqrt(nx*nx+ny*ny+1)
    normal=np.stack([nx/norm,ny/norm,1/norm],axis=-1)
    Image.fromarray(uint(color)).save(MAPS/'tranche.jpg',quality=92,subsampling=0,optimize=True)
    Image.fromarray(uint(normal*127.5+127.5)).save(MAPS/'tranche_normal.jpg',quality=93,subsampling=0)

def opened_page(side):
    s=(768,1024)
    h,w=s[1],s[0]
    yy,xx=np.mgrid[:h,:w]
    margin=np.exp(-np.minimum.reduce([xx,yy,w-1-xx,h-1-yy])/42)
    aging=7.*margin+4.2*noise((h,w),22)+1.1*noise((h,w),2)
    paper=uint(np.array([225,207,170])[None,None,:]-aging[...,None])
    im=Image.fromarray(paper)
    d=ImageDraw.Draw(im)
    ink=(62,34,24)
    sepia=(127,82,55)
    f=lambda sz,mode='Roman':font(sz,mode)
    def center(label,y,sz,mode='Roman',c=ink):
        d.text((384,y),label,font=f(sz,mode),anchor='mt',fill=c)
    d.rectangle((32,27,736,997),outline=(149,111,74),width=2)
    if side=='gauche':
        center('JEAN DE LA FONTAINE',125,30,'Bold')
        center('Fables',235,106,'Bold')
        center('choisies',335,80,'Italic')
        center('LIVRE PREMIER',452,30)
        for i in range(2):
            d.ellipse((258+i*10,527+i*10,510-i*10,779-i*10),outline=sepia,width=3 if i==0 else 2)
        pts=[(-67,-54),(-50,13),(0,63),(50,13),(67,-54),(32,-31),(0,-41),(-32,-31),(-67,-54)]
        d.line([(384+x,653+y) for x,y in pts],fill=ink,width=5,joint='curve')
        d.line([(341,641),(356,659),(370,664),(384,697),(398,664),(412,659),(427,641)],fill=sepia,width=5)
        center('BIBLIOTHÈQUE OASIS',868,27)
    else:
        center('FABLE II',105,35)
        center('Le Corbeau',167,66,'Italic')
        center('et le Renard',239,66,'Italic')
        d.line((264,330,504,330),fill=sepia,width=2)
        d.text((112,410),'Maître Corbeau, sur un arbre perché,\n\nTenait en son bec un fromage.',font=f(34,'Italic'),fill=ink)
        para='Le renard, attiré par le fromage, flatte le corbeau et lui demande de chanter. À peine l’oiseau ouvre-t-il le bec que le fromage tombe. Le renard s’en empare et lui laisse une leçon sur les flatteurs.'
        text=''; y=593; fn=f(30)
        for word in para.split():
            nxt=(text+' '+word).strip()
            if text and fn.getlength(nxt)>529:
                d.text((118,y),text,font=fn,fill=ink)
                y+=42
                text=word
            else:text=nxt
        d.text((118,y),text,font=fn,fill=ink)
        center('2',913,24)
    im.save(MAPS/f'fables_ouvert_{side}.jpg',quality=93,subsampling=0)

if __name__=='__main__':
    atlas()
    opened_page('gauche')
    opened_page('droite')
