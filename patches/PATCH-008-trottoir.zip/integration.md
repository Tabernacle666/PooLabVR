# PATCH-008 · Trottoir modulaire en béton

Modules glTF avec buffers BIN et textures PBR originales partagées. Garder le dossier trottoir intact lors de l'import. La dalle et la bordure ont leurs propres nœuds. Béton de 1,65 m de large. La texture se répète tous les 0,48 m sur des UV mesurées en mètres. Les variantes patinées ajoutent une légère variation de surface et de teinte avec les mêmes ancrages.

| Module | Profil de bord et raccord |
| --- | --- |
| droit | Longueur 1,20 m, haut vers haut. |
| rampe_descente | Longueur 1,20 m, haut vers bas. Bordure abaissée progressivement et tablier incliné vers la rue. |
| palier_bas | Longueur 1,20 m, bas vers bas. Répéter le module pour obtenir la largeur requise de l'entrée carrossable. |
| rampe_montee | Longueur 1,20 m, bas vers haut. |
| coin_exterieur | Arrondi de 90°, rayon de 2,15 m au bord de chaussée, haut vers haut. |
| coin_interieur | Arrondi de 90° dans l'autre sens, rayon de 1,35 m au bord de chaussée, haut vers haut. |

Le repère +Y est vertical, +X avance sur le module à l'entrée, +Z pointe vers la chaussée à l'entrée. Les connecteurs entree et sortie sont au niveau de la route, à ras du bord avant. Leur +X donne la tangente de la chaîne. Superposer le repère entree du bloc suivant au repère sortie du bloc précédent. Les extrémités de béton laissent un joint nominal de 4,4 mm. Les connecteurs annoncent le niveau nominal du tablier au bord avant, haut à 155 mm ou bas à 37 mm. Le dessus de la bordure est 20 mm plus haut.

**Exemple d'entrée carrossable** · droit → rampe_descente → palier_bas → palier_bas → rampe_montee → droit. Les paliers centraux donnent une ouverture basse de 2,40 m avant les rampes. Le fond du trottoir conserve sa hauteur. Selon le véhicule visé, régler le nombre de paliers.

Le tracé fixe le type et le niveau de raccord. Pour chaque bloc, le manifeste expose deux finitions compatibles, standard et patine. Fixer une finition si le placement l'exige, ou la tirer par identifiant stable et graine. En test, assembler aussi les deux coins et vérifier le raccord du haut de bordure et du tablier en vue rasante, puis franchir l'entrée avec le véhicule de référence d'OASIS. Le comportement de collision et le franchissement restent à qualifier en jeu.
